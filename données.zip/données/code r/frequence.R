# ============================================================================
# ANALYSES APPROFONDIES : EFFETS DE LA FRÉQUENCE DE JEU
# ============================================================================
library(readxl)
library(ggplot2)
library(dplyr)

# ===== CHARGEMENT =====
donnees_raw <- read_excel("tableau fin mémoire.xlsx")
donnees <- donnees_raw

colnames(donnees) <- c("ID", "Age", "Genre", "Type_jeu", "Type_joueur",
                       "Frequence", "Niveau_estime", "Niveau_reel",
                       "Toxicite_exposition", "Toxicite_impact",
                       "STAI_Etat", "STAI_Trait", "WHO5", "Rosenberg",
                       "Sommeil_latence", "Sommeil_difficulte",
                       "Sommeil_qualite", "Fatigue_ressenti")

# Conversion colonnes texte → scores numériques
donnees$Sommeil_latence <- case_when(
  grepl("15min|15 min|égale à 15", donnees_raw[[15]])  ~ 1,
  grepl("16 à 30|16à30", donnees_raw[[15]])            ~ 2,
  grepl("31 à 60|31à60", donnees_raw[[15]])            ~ 3,
  grepl("Supérieur à 60|60min", donnees_raw[[15]])     ~ 4,
  TRUE ~ NA_real_
)

donnees$Sommeil_difficulte <- case_when(
  grepl("Pas au cours", donnees_raw[[16]])             ~ 0,
  grepl("Inférieur à 1", donnees_raw[[16]])            ~ 1,
  grepl("2 à 3 fois", donnees_raw[[16]])               ~ 2,
  grepl("3 à 4 fois", donnees_raw[[16]])               ~ 3,
  TRUE ~ NA_real_
)

# Conversion numérique
colonnes_num <- c("STAI_Etat", "STAI_Trait", "WHO5", "Rosenberg",
                  "Toxicite_exposition", "Toxicite_impact",
                  "Niveau_estime", "Niveau_reel",
                  "Sommeil_qualite", "Fatigue_ressenti")

for(col in colonnes_num) {
  donnees[[col]] <- as.numeric(donnees[[col]])
}

# Variables dérivées
donnees$Genre_clean <- factor(
  ifelse(grepl("Homme|homme", donnees$Genre), "Homme",
         ifelse(grepl("Femme|femme", donnees$Genre), "Femme", NA)),
  levels = c("Femme", "Homme")
)

donnees$Type_jeu_cat <- ifelse(
  grepl("Compétitif", donnees$Type_jeu) & !grepl("Non", donnees$Type_jeu),
  "Compétitif",
  ifelse(grepl("Non", donnees$Type_jeu), "Non-compétitif", "Les deux")
)

donnees$Freq_simple <- factor(
  ifelse(grepl("tous les jours", donnees$Frequence), "Quotidien", "Non-quotidien"),
  levels = c("Non-quotidien", "Quotidien")
)

# Sous-groupes
donnees_genre <- donnees[!is.na(donnees$Genre_clean), ]
quotidien     <- donnees[donnees$Freq_simple == "Quotidien" & !is.na(donnees$Freq_simple), ]
non_quotidien <- donnees[donnees$Freq_simple == "Non-quotidien" & !is.na(donnees$Freq_simple), ]

cat("================================================================================\n")
cat("ANALYSES APPROFONDIES SUR LA FRÉQUENCE DE JEU\n")
cat("================================================================================\n")
cat("N total =", nrow(donnees), "participants\n")
cat("Quotidien =", sum(donnees$Freq_simple == "Quotidien", na.rm = TRUE), "\n")
cat("Non-quotidien =", sum(donnees$Freq_simple == "Non-quotidien", na.rm = TRUE), "\n\n")

# ============================================================================
# 1. STATISTIQUES DESCRIPTIVES PAR FRÉQUENCE
# ============================================================================

cat("================================================================================\n")
cat("1. SANTÉ MENTALE SELON LA FRÉQUENCE DE JEU (EFFET PRINCIPAL)\n")
cat("================================================================================\n\n")

stats_freq_base <- donnees %>%
  group_by(Freq_simple) %>%
  summarise(
    N = n(),
    M_STAI_Etat  = mean(STAI_Etat, na.rm = TRUE),
    ET_STAI_Etat = sd(STAI_Etat, na.rm = TRUE),
    M_STAI_Trait  = mean(STAI_Trait, na.rm = TRUE),
    ET_STAI_Trait = sd(STAI_Trait, na.rm = TRUE),
    M_WHO5  = mean(WHO5, na.rm = TRUE),
    ET_WHO5 = sd(WHO5, na.rm = TRUE),
    M_Rosenberg  = mean(Rosenberg, na.rm = TRUE),
    ET_Rosenberg = sd(Rosenberg, na.rm = TRUE),
    .groups = "drop"
  )

print(stats_freq_base)

cat("\nTests t (Quotidien vs Non-quotidien) :\n")
cat("----------------------------------------\n")

test_freq_etat     <- t.test(STAI_Etat ~ Freq_simple, data = donnees)
test_freq_trait    <- t.test(STAI_Trait ~ Freq_simple, data = donnees)
test_freq_who5     <- t.test(WHO5 ~ Freq_simple, data = donnees)
test_freq_rosenberg <- t.test(Rosenberg ~ Freq_simple, data = donnees)

cat("Anxiété-État : t =", round(test_freq_etat$statistic, 3),
    ", p =", round(test_freq_etat$p.value, 3),
    ifelse(test_freq_etat$p.value < 0.05, " ***", ""), "\n")
cat("Anxiété-Trait : t =", round(test_freq_trait$statistic, 3),
    ", p =", round(test_freq_trait$p.value, 3),
    ifelse(test_freq_trait$p.value < 0.05, " ***", ""), "\n")
cat("Bien-être : t =", round(test_freq_who5$statistic, 3),
    ", p =", round(test_freq_who5$p.value, 3),
    ifelse(test_freq_who5$p.value < 0.05, " ***", ""), "\n")
cat("Estime de soi : t =", round(test_freq_rosenberg$statistic, 3),
    ", p =", round(test_freq_rosenberg$p.value, 3),
    ifelse(test_freq_rosenberg$p.value < 0.05, " ***", ""), "\n")

par(mfrow = c(2, 2))
boxplot(STAI_Etat ~ Freq_simple, data = donnees,
        main = paste0("Anxiété-État\np = ", round(test_freq_etat$p.value, 3)),
        col = c("lightgreen", "lightyellow"), ylab = "STAI-État")
boxplot(STAI_Trait ~ Freq_simple, data = donnees,
        main = paste0("Anxiété-Trait\np = ", round(test_freq_trait$p.value, 3)),
        col = c("lightgreen", "lightyellow"), ylab = "STAI-Trait")
boxplot(WHO5 ~ Freq_simple, data = donnees,
        main = paste0("Bien-être\np = ", round(test_freq_who5$p.value, 3)),
        col = c("lightgreen", "lightyellow"), ylab = "WHO-5")
boxplot(Rosenberg ~ Freq_simple, data = donnees,
        main = paste0("Estime de soi\np = ", round(test_freq_rosenberg$p.value, 3)),
        col = c("lightgreen", "lightyellow"), ylab = "Rosenberg")
par(mfrow = c(1, 1))

# ============================================================================
# 2. FRÉQUENCE × TYPE DE JEU → ANXIÉTÉ
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("2. FRÉQUENCE × TYPE DE JEU → ANXIÉTÉ\n")
cat("================================================================================\n\n")

cat("Question : Les joueurs quotidiens compétitifs sont-ils plus anxieux ?\n\n")

donnees_h2 <- donnees[donnees$Type_jeu_cat != "Les deux", ]

cat("Répartition Fréquence × Type de jeu :\n")
print(table(donnees_h2$Freq_simple, donnees_h2$Type_jeu_cat))

moyennes_h2 <- donnees_h2 %>%
  group_by(Freq_simple, Type_jeu_cat) %>%
  summarise(
    n = n(),
    M_anxiete  = mean(STAI_Etat, na.rm = TRUE),
    ET_anxiete = sd(STAI_Etat, na.rm = TRUE),
    .groups = "drop"
  )

cat("\nMoyennes Anxiété-État :\n")
moyennes_h2 %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

anova_h2 <- aov(STAI_Etat ~ Freq_simple * Type_jeu_cat, data = donnees_h2)
cat("\nANOVA Fréquence × Type de jeu :\n")
print(summary(anova_h2))

ggplot(moyennes_h2, aes(x = Type_jeu_cat, y = M_anxiete,
                        color = Freq_simple, group = Freq_simple)) +
  geom_line(linewidth = 2) +
  geom_point(size = 5) +
  labs(title = "Interaction Fréquence × Type de jeu → Anxiété",
       subtitle = "Les joueurs quotidiens compétitifs sont-ils plus anxieux ?",
       x = "Type de jeu", y = "Anxiété-État moyenne",
       color = "Fréquence") +
  theme_minimal() +
  scale_color_manual(values = c("Non-quotidien" = "lightgreen", "Quotidien" = "darkorange"))

# ============================================================================
# 3. FRÉQUENCE × TOXICITÉ
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("3. FRÉQUENCE × TOXICITÉ\n")
cat("================================================================================\n\n")

cat("Question : Les joueurs quotidiens sont-ils plus exposés à la toxicité ?\n\n")

stats_tox_freq <- donnees %>%
  group_by(Freq_simple) %>%
  summarise(
    n = n(),
    M_exposition  = mean(Toxicite_exposition, na.rm = TRUE),
    ET_exposition = sd(Toxicite_exposition, na.rm = TRUE),
    M_impact      = mean(Toxicite_impact, na.rm = TRUE),
    ET_impact     = sd(Toxicite_impact, na.rm = TRUE),
    .groups = "drop"
  )

cat("Toxicité par fréquence :\n")
stats_tox_freq %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_freq_tox_exp <- t.test(Toxicite_exposition ~ Freq_simple, data = donnees)
test_freq_tox_imp <- t.test(Toxicite_impact ~ Freq_simple, data = donnees)

cat("\nTests t :\n")
cat("  Exposition : t =", round(test_freq_tox_exp$statistic, 3),
    ", p =", round(test_freq_tox_exp$p.value, 3),
    ifelse(test_freq_tox_exp$p.value < 0.05, " ***", ""), "\n")
cat("  Impact : t =", round(test_freq_tox_imp$statistic, 3),
    ", p =", round(test_freq_tox_imp$p.value, 3),
    ifelse(test_freq_tox_imp$p.value < 0.05, " ***", ""), "\n")

par(mfrow = c(1, 2))
boxplot(Toxicite_exposition ~ Freq_simple, data = donnees,
        main = paste0("Exposition toxicité\npar fréquence\np = ",
                      round(test_freq_tox_exp$p.value, 3)),
        col = c("lightgreen", "lightyellow"), ylab = "Score d'exposition")
boxplot(Toxicite_impact ~ Freq_simple, data = donnees,
        main = paste0("Impact émotionnel\npar fréquence\np = ",
                      round(test_freq_tox_imp$p.value, 3)),
        col = c("lightgreen", "lightyellow"), ylab = "Score d'impact")
par(mfrow = c(1, 1))

# ============================================================================
# 4. FRÉQUENCE × SOMMEIL
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("4. FRÉQUENCE × QUALITÉ DU SOMMEIL\n")
cat("================================================================================\n\n")

cat("Question : Les joueurs quotidiens dorment-ils moins bien ?\n\n")

stats_sommeil_freq <- donnees %>%
  group_by(Freq_simple) %>%
  summarise(
    n = n(),
    M_qualite    = mean(Sommeil_qualite, na.rm = TRUE),
    ET_qualite   = sd(Sommeil_qualite, na.rm = TRUE),
    M_latence    = mean(Sommeil_latence, na.rm = TRUE),
    M_difficulte = mean(Sommeil_difficulte, na.rm = TRUE),
    .groups = "drop"
  )

cat("Qualité du sommeil par fréquence :\n")
stats_sommeil_freq %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_freq_sommeil   <- t.test(Sommeil_qualite ~ Freq_simple, data = donnees)
test_freq_latence   <- t.test(Sommeil_latence ~ Freq_simple, data = donnees)
test_freq_difficulte <- t.test(Sommeil_difficulte ~ Freq_simple, data = donnees)

cat("\nTests t :\n")
cat("  Qualité : t =", round(test_freq_sommeil$statistic, 3),
    ", p =", round(test_freq_sommeil$p.value, 3),
    ifelse(test_freq_sommeil$p.value < 0.05, " ***", ""), "\n")
cat("  Latence : t =", round(test_freq_latence$statistic, 3),
    ", p =", round(test_freq_latence$p.value, 3),
    ifelse(test_freq_latence$p.value < 0.05, " ***", ""), "\n")
cat("  Difficultés : t =", round(test_freq_difficulte$statistic, 3),
    ", p =", round(test_freq_difficulte$p.value, 3),
    ifelse(test_freq_difficulte$p.value < 0.05, " ***", ""), "\n")

# Corrélations Sommeil → Anxiété par fréquence
cor_q_sommeil  <- cor.test(quotidien$Sommeil_qualite, quotidien$STAI_Etat)
cor_nq_sommeil <- cor.test(non_quotidien$Sommeil_qualite, non_quotidien$STAI_Etat)

cat("\nCorrélations Sommeil → Anxiété par fréquence :\n")
cat("  Quotidien : r =", round(cor_q_sommeil$estimate, 3),
    ", p =", round(cor_q_sommeil$p.value, 3),
    ifelse(cor_q_sommeil$p.value < 0.05, " ***", ""), "\n")
cat("  Non-quotidien : r =", round(cor_nq_sommeil$estimate, 3),
    ", p =", round(cor_nq_sommeil$p.value, 3),
    ifelse(cor_nq_sommeil$p.value < 0.05, " ***", ""), "\n")

boxplot(Sommeil_qualite ~ Freq_simple, data = donnees,
        main = paste0("Qualité du sommeil par fréquence\np = ",
                      round(test_freq_sommeil$p.value, 3)),
        col = c("lightgreen", "lightyellow"),
        ylab = "Qualité du sommeil (1-5)")

# ============================================================================
# 5. FRÉQUENCE × GENRE
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("5. FRÉQUENCE × GENRE\n")
cat("================================================================================\n\n")

cat("Répartition Fréquence × Genre :\n")
print(table(donnees_genre$Genre_clean, donnees_genre$Freq_simple))

prop_freq_genre <- donnees_genre %>%
  group_by(Genre_clean, Freq_simple) %>%
  summarise(n = n(), .groups = "drop") %>%
  group_by(Genre_clean) %>%
  mutate(pct = round(n / sum(n) * 100, 1))

print(prop_freq_genre)

moyennes_h5 <- donnees_genre %>%
  group_by(Genre_clean, Freq_simple) %>%
  summarise(
    n = n(),
    M_anxiete  = mean(STAI_Etat, na.rm = TRUE),
    ET_anxiete = sd(STAI_Etat, na.rm = TRUE),
    .groups = "drop"
  )

cat("\nMoyennes Anxiété-État par Genre × Fréquence :\n")
moyennes_h5 %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

anova_h5 <- aov(STAI_Etat ~ Genre_clean * Freq_simple, data = donnees_genre)
cat("\nANOVA Genre × Fréquence :\n")
print(summary(anova_h5))

# ============================================================================
# 6. FRÉQUENCE × PERCEPTION DU NIVEAU
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("6. FRÉQUENCE × PERCEPTION DU NIVEAU\n")
cat("================================================================================\n\n")

cat("Question : Les joueurs quotidiens se perçoivent-ils mieux ?\n\n")

donnees$Ecart_niveau <- donnees$Niveau_reel - donnees$Niveau_estime

stats_niveau_freq <- donnees %>%
  group_by(Freq_simple) %>%
  summarise(
    n = n(),
    M_ecart  = mean(Ecart_niveau, na.rm = TRUE),
    ET_ecart = sd(Ecart_niveau, na.rm = TRUE),
    M_estime = mean(Niveau_estime, na.rm = TRUE),
    M_reel   = mean(Niveau_reel, na.rm = TRUE),
    .groups = "drop"
  )

cat("Perception du niveau par fréquence :\n")
stats_niveau_freq %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_freq_estime <- t.test(Niveau_estime ~ Freq_simple, data = donnees)
test_freq_reel   <- t.test(Niveau_reel ~ Freq_simple, data = donnees)
test_freq_ecart  <- t.test(Ecart_niveau ~ Freq_simple, data = donnees)

cat("\nTests t :\n")
cat("  Niveau estimé : t =", round(test_freq_estime$statistic, 3),
    ", p =", round(test_freq_estime$p.value, 3),
    ifelse(test_freq_estime$p.value < 0.05, " ***", ""), "\n")
cat("  Niveau réel : t =", round(test_freq_reel$statistic, 3),
    ", p =", round(test_freq_reel$p.value, 3),
    ifelse(test_freq_reel$p.value < 0.05, " ***", ""), "\n")
cat("  Écart (surestimation) : t =", round(test_freq_ecart$statistic, 3),
    ", p =", round(test_freq_ecart$p.value, 3),
    ifelse(test_freq_ecart$p.value < 0.05, " ***", ""), "\n")

cat("\nInterprétation :\n")
cat("  Écart > 0 = Surestimation\n")
cat("  Écart < 0 = Sous-estimation\n")

# ============================================================================
# RÉSUMÉ FINAL FRÉQUENCE
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("RÉSUMÉ : EFFETS DE LA FRÉQUENCE DE JEU\n")
cat("================================================================================\n\n")

cat("SANTÉ MENTALE DE BASE :\n")
cat("  Anxiété-État : p =", round(test_freq_etat$p.value, 3),
    ifelse(test_freq_etat$p.value < 0.05, " *** Quotidien plus anxieux",
           " (pas de différence)"), "\n")
cat("  Anxiété-Trait : p =", round(test_freq_trait$p.value, 3),
    ifelse(test_freq_trait$p.value < 0.05, " ***",
           " (pas de différence)"), "\n")
cat("  Bien-être : p =", round(test_freq_who5$p.value, 3),
    ifelse(test_freq_who5$p.value < 0.05, " ***",
           " (pas de différence)"), "\n")
cat("  Estime de soi : p =", round(test_freq_rosenberg$p.value, 3),
    ifelse(test_freq_rosenberg$p.value < 0.05, " ***",
           " (pas de différence)"), "\n\n")

cat("TOXICITÉ :\n")
cat("  Exposition : p =", round(test_freq_tox_exp$p.value, 3),
    ifelse(test_freq_tox_exp$p.value < 0.05, " *** Quotidien plus exposé",
           " (pas de différence)"), "\n")
cat("  Impact : p =", round(test_freq_tox_imp$p.value, 3),
    ifelse(test_freq_tox_imp$p.value < 0.05, " *** Différence",
           " (pas de différence)"), "\n\n")

cat("SOMMEIL :\n")
cat("  Qualité : p =", round(test_freq_sommeil$p.value, 3),
    ifelse(test_freq_sommeil$p.value < 0.05, " ***",
           " (pas de différence)"), "\n")
cat("  Latence : p =", round(test_freq_latence$p.value, 3),
    ifelse(test_freq_latence$p.value < 0.05, " ***",
           " (pas de différence)"), "\n")
cat("  Difficultés : p =", round(test_freq_difficulte$p.value, 3),
    ifelse(test_freq_difficulte$p.value < 0.05, " ***",
           " (pas de différence)"), "\n\n")

cat("PERCEPTION DU NIVEAU :\n")
cat("  Niveau estimé : p =", round(test_freq_estime$p.value, 3),
    ifelse(test_freq_estime$p.value < 0.05, " *** Quotidien se perçoit meilleur",
           " (pas de différence)"), "\n")
cat("  Niveau réel : p =", round(test_freq_reel$p.value, 3),
    ifelse(test_freq_reel$p.value < 0.05, " ***",
           " (pas de différence)"), "\n")
cat("  Écart : p =", round(test_freq_ecart$p.value, 3),
    ifelse(test_freq_ecart$p.value < 0.05, " ***",
           " (pas de différence)"), "\n\n")

cat("*** = p < 0.05 (significatif)\n")
cat("================================================================================\n")