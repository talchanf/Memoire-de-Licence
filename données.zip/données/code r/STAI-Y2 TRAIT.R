# ============================================================================
# ANALYSES APPROFONDIES : STAI-Y2 TRAIT (ANXIÉTÉ-TRAIT)
# ============================================================================
library(readxl)
library(ggplot2)
library(dplyr)

# ===== CHARGEMENT =====
donnees_raw <- read_excel("tableau fin mémoire.xlsx")
donnees <- donnees_raw

colnames(donnees) <- c("ID", "Age", "Genre", "Type_jeu", "Type_joueur",
                       "Frequence", "Niveau_estime", "Niveau_reel",
                       "Toxicite_exposition", "Toxicite_impact",
                       "STAI_Etat", "STAI_Trait", "WHO5", "Rosenberg",
                       "Sommeil_latence", "Sommeil_difficulte",
                       "Sommeil_qualite", "Fatigue_ressenti")

# Conversion colonnes texte → scores numériques
donnees$Sommeil_latence <- case_when(
  grepl("15min|15 min|égale à 15", donnees_raw[[15]])  ~ 1,
  grepl("16 à 30|16à30", donnees_raw[[15]])            ~ 2,
  grepl("31 à 60|31à60", donnees_raw[[15]])            ~ 3,
  grepl("Supérieur à 60|60min", donnees_raw[[15]])     ~ 4,
  TRUE ~ NA_real_
)

donnees$Sommeil_difficulte <- case_when(
  grepl("Pas au cours", donnees_raw[[16]])             ~ 0,
  grepl("Inférieur à 1", donnees_raw[[16]])            ~ 1,
  grepl("2 à 3 fois", donnees_raw[[16]])               ~ 2,
  grepl("3 à 4 fois", donnees_raw[[16]])               ~ 3,
  TRUE ~ NA_real_
)

donnees$Age <- case_when(
  grepl("16", donnees_raw[[2]]) ~ 1,
  grepl("18", donnees_raw[[2]]) ~ 2,
  grepl("22", donnees_raw[[2]]) ~ 3,
  grepl("26", donnees_raw[[2]]) ~ 4,
  grepl("31", donnees_raw[[2]]) ~ 5,
  TRUE ~ NA_real_
)

# Conversion numérique
colonnes_num <- c("STAI_Etat", "STAI_Trait", "WHO5", "Rosenberg",
                  "Toxicite_exposition", "Toxicite_impact",
                  "Niveau_estime", "Niveau_reel",
                  "Sommeil_qualite", "Fatigue_ressenti")

for(col in colonnes_num) {
  donnees[[col]] <- as.numeric(donnees[[col]])
}

# Variables dérivées
donnees$Genre_clean <- factor(
  ifelse(grepl("Homme|homme", donnees$Genre), "Homme",
         ifelse(grepl("Femme|femme", donnees$Genre), "Femme", NA)),
  levels = c("Femme", "Homme")
)

donnees$Type_jeu_cat <- ifelse(
  grepl("Compétitif", donnees$Type_jeu) & !grepl("Non", donnees$Type_jeu),
  "Compétitif",
  ifelse(grepl("Non", donnees$Type_jeu), "Non-compétitif", "Les deux")
)

donnees$Freq_simple <- factor(
  ifelse(grepl("tous les jours", donnees$Frequence), "Quotidien", "Non-quotidien"),
  levels = c("Non-quotidien", "Quotidien")
)

donnees$Age_cat <- factor(donnees$Age,
                          labels = c("16-18", "18-21", "22-25", "26-30", "31+"))

# Sous-groupes
donnees_genre <- donnees[!is.na(donnees$Genre_clean), ]

cat("================================================================================\n")
cat("ANALYSES APPROFONDIES : STAI-Y2 TRAIT (ANXIÉTÉ-TRAIT)\n")
cat("================================================================================\n")
cat("N total =", nrow(donnees), "participants\n")
cat("M STAI-Trait =", round(mean(donnees$STAI_Trait, na.rm = TRUE), 2), "\n")
cat("ET STAI-Trait =", round(sd(donnees$STAI_Trait, na.rm = TRUE), 2), "\n")
cat("Min =", min(donnees$STAI_Trait, na.rm = TRUE), "\n")
cat("Max =", max(donnees$STAI_Trait, na.rm = TRUE), "\n\n")

# ============================================================================
# 1. DESCRIPTION DE L'ANXIÉTÉ-TRAIT
# ============================================================================

cat("================================================================================\n")
cat("1. DESCRIPTION DE L'ANXIÉTÉ-TRAIT\n")
cat("================================================================================\n\n")

hist(donnees$STAI_Trait,
     main = "Distribution du STAI-Y2 Trait",
     xlab = "Score STAI-Trait",
     col = "lavender", border = "purple",
     breaks = 10)
abline(v = mean(donnees$STAI_Trait, na.rm = TRUE), col = "red", lwd = 2, lty = 2)
legend("topright", legend = paste0("Moyenne = ",
                                   round(mean(donnees$STAI_Trait, na.rm = TRUE), 1)),
       col = "red", lty = 2, lwd = 2)

# Seuil clinique STAI-Trait (score > 46)
cat("Seuil clinique (score > 46) :\n")
cat("  N au-dessus du seuil =", sum(donnees$STAI_Trait > 46, na.rm = TRUE), "\n")
cat("  % au-dessus du seuil =",
    round(mean(donnees$STAI_Trait > 46, na.rm = TRUE) * 100, 1), "%\n\n")

# ============================================================================
# 2. CORRÉLATIONS : FACTEURS PRÉDICTEURS DE L'ANXIÉTÉ-TRAIT
# ============================================================================

cat("================================================================================\n")
cat("2. FACTEURS PRÉDICTEURS DE L'ANXIÉTÉ-TRAIT (CORRÉLATIONS)\n")
cat("================================================================================\n\n")

predicteurs        <- c("STAI_Etat", "WHO5", "Rosenberg",
                        "Toxicite_exposition", "Toxicite_impact",
                        "Sommeil_qualite", "Sommeil_latence", "Sommeil_difficulte",
                        "Fatigue_ressenti", "Niveau_estime", "Niveau_reel", "Age")
labels_predicteurs <- c("Anxiété-État", "Bien-être (WHO-5)", "Estime de soi",
                        "Exposition toxicité", "Impact toxicité",
                        "Qualité sommeil", "Latence sommeil", "Difficultés sommeil",
                        "Fatigue ressentie", "Niveau estimé", "Niveau réel", "Âge")

cat("Corrélations avec STAI-Y2 Trait :\n")
cat("-----------------------------------\n")
for(i in seq_along(predicteurs)) {
  cor_res <- cor.test(donnees$STAI_Trait, donnees[[predicteurs[i]]])
  cat(labels_predicteurs[i], ": r =", round(cor_res$estimate, 3),
      ", p =", round(cor_res$p.value, 3),
      ifelse(cor_res$p.value < 0.05, " ***", ""), "\n")
}

# Graphiques des corrélations significatives
par(mfrow = c(2, 3))
for(i in seq_along(predicteurs)) {
  cor_res <- cor.test(donnees$STAI_Trait, donnees[[predicteurs[i]]])
  if(cor_res$p.value < 0.05) {
    plot(donnees[[predicteurs[i]]], donnees$STAI_Trait,
         pch = 19, col = rgb(0.5, 0.2, 0.8, 0.5), cex = 1.5,
         xlab = labels_predicteurs[i],
         ylab = "STAI-Trait",
         main = paste0(labels_predicteurs[i], "\nr = ",
                       round(cor_res$estimate, 3),
                       ", p = ", round(cor_res$p.value, 3)))
    abline(lm(donnees$STAI_Trait ~ donnees[[predicteurs[i]]]),
           col = "purple", lwd = 2)
  }
}
par(mfrow = c(1, 1))

# ============================================================================
# 3. RÉGRESSION MULTIPLE : PRÉDICTEURS DE L'ANXIÉTÉ-TRAIT
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("3. RÉGRESSION MULTIPLE : QUELS FACTEURS PRÉDISENT L'ANXIÉTÉ-TRAIT ?\n")
cat("================================================================================\n\n")

modele_trait <- lm(STAI_Trait ~ STAI_Etat + WHO5 + Rosenberg +
                     Toxicite_exposition + Toxicite_impact +
                     Sommeil_qualite + Fatigue_ressenti,
                   data = donnees)

cat("Modèle de régression multiple :\n")
print(summary(modele_trait))

cat("\nVariance expliquée (R²) =",
    round(summary(modele_trait)$r.squared, 3), "\n")
cat("R² ajusté =",
    round(summary(modele_trait)$adj.r.squared, 3), "\n")

# ============================================================================
# 4. ANXIÉTÉ-TRAIT SELON LE GENRE
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("4. ANXIÉTÉ-TRAIT SELON LE GENRE\n")
cat("================================================================================\n\n")

stats_trait_genre <- donnees_genre %>%
  group_by(Genre_clean) %>%
  summarise(
    n = n(),
    M_STAI_Trait  = mean(STAI_Trait, na.rm = TRUE),
    ET_STAI_Trait = sd(STAI_Trait, na.rm = TRUE),
    Min = min(STAI_Trait, na.rm = TRUE),
    Max = max(STAI_Trait, na.rm = TRUE),
    .groups = "drop"
  )

stats_trait_genre %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_trait_genre <- t.test(STAI_Trait ~ Genre_clean, data = donnees_genre)
cat("\nTest t : t =", round(test_trait_genre$statistic, 3),
    ", p =", round(test_trait_genre$p.value, 3),
    ifelse(test_trait_genre$p.value < 0.05, " ***", ""), "\n")

boxplot(STAI_Trait ~ Genre_clean, data = donnees_genre,
        main = paste0("Anxiété-Trait par genre\np = ",
                      round(test_trait_genre$p.value, 3)),
        col = c("pink", "lightblue"), ylab = "STAI-Trait")

# ============================================================================
# 5. ANXIÉTÉ-TRAIT SELON LE TYPE DE JEU
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("5. ANXIÉTÉ-TRAIT SELON LE TYPE DE JEU\n")
cat("================================================================================\n\n")

donnees_h5 <- donnees[donnees$Type_jeu_cat != "Les deux", ]
donnees_h5$Type_jeu_cat <- factor(donnees_h5$Type_jeu_cat,
                                  levels = c("Non-compétitif", "Compétitif"))

stats_trait_jeu <- donnees_h5 %>%
  group_by(Type_jeu_cat) %>%
  summarise(
    n = n(),
    M_STAI_Trait  = mean(STAI_Trait, na.rm = TRUE),
    ET_STAI_Trait = sd(STAI_Trait, na.rm = TRUE),
    Min = min(STAI_Trait, na.rm = TRUE),
    Max = max(STAI_Trait, na.rm = TRUE),
    .groups = "drop"
  )

stats_trait_jeu %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_trait_jeu <- t.test(STAI_Trait ~ Type_jeu_cat, data = donnees_h5)
cat("\nTest t : t =", round(test_trait_jeu$statistic, 3),
    ", p =", round(test_trait_jeu$p.value, 3),
    ifelse(test_trait_jeu$p.value < 0.05, " ***", ""), "\n")

boxplot(STAI_Trait ~ Type_jeu_cat, data = donnees_h5,
        main = paste0("Anxiété-Trait par type de jeu\np = ",
                      round(test_trait_jeu$p.value, 3)),
        col = c("lightgreen", "lightyellow"), ylab = "STAI-Trait")

# ============================================================================
# 6. ANXIÉTÉ-TRAIT SELON LA FRÉQUENCE DE JEU
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("6. ANXIÉTÉ-TRAIT SELON LA FRÉQUENCE DE JEU\n")
cat("================================================================================\n\n")

stats_trait_freq <- donnees %>%
  group_by(Freq_simple) %>%
  summarise(
    n = n(),
    M_STAI_Trait  = mean(STAI_Trait, na.rm = TRUE),
    ET_STAI_Trait = sd(STAI_Trait, na.rm = TRUE),
    Min = min(STAI_Trait, na.rm = TRUE),
    Max = max(STAI_Trait, na.rm = TRUE),
    .groups = "drop"
  )

stats_trait_freq %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_trait_freq <- t.test(STAI_Trait ~ Freq_simple, data = donnees)
cat("\nTest t : t =", round(test_trait_freq$statistic, 3),
    ", p =", round(test_trait_freq$p.value, 3),
    ifelse(test_trait_freq$p.value < 0.05, " ***", ""), "\n")

boxplot(STAI_Trait ~ Freq_simple, data = donnees,
        main = paste0("Anxiété-Trait par fréquence\np = ",
                      round(test_trait_freq$p.value, 3)),
        col = c("lightgreen", "lightyellow"), ylab = "STAI-Trait")

# ============================================================================
# 7. ANXIÉTÉ-TRAIT SELON L'ÂGE
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("7. ANXIÉTÉ-TRAIT SELON L'ÂGE\n")
cat("================================================================================\n\n")

stats_trait_age <- donnees %>%
  group_by(Age_cat) %>%
  summarise(
    n = n(),
    M_STAI_Trait  = mean(STAI_Trait, na.rm = TRUE),
    ET_STAI_Trait = sd(STAI_Trait, na.rm = TRUE),
    .groups = "drop"
  )

stats_trait_age %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

anova_trait_age <- aov(STAI_Trait ~ Age_cat, data = donnees)
cat("\nANOVA Âge → Anxiété-Trait :\n")
print(summary(anova_trait_age))

cor_age_trait <- cor.test(donnees$Age, donnees$STAI_Trait)
cat("\nCorrélation Age → Anxiété-Trait : r =", round(cor_age_trait$estimate, 3),
    ", p =", round(cor_age_trait$p.value, 3),
    ifelse(cor_age_trait$p.value < 0.05, " ***", ""), "\n")

boxplot(STAI_Trait ~ Age_cat, data = donnees,
        main = "Anxiété-Trait par tranche d'âge",
        col = "lavender", ylab = "STAI-Trait")

# ============================================================================
# RÉSUMÉ FINAL STAI-TRAIT
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("RÉSUMÉ : FACTEURS ASSOCIÉS À L'ANXIÉTÉ-TRAIT\n")
cat("================================================================================\n\n")

cat("DESCRIPTION :\n")
cat("  Moyenne =", round(mean(donnees$STAI_Trait, na.rm = TRUE), 2), "\n")
cat("  ET =", round(sd(donnees$STAI_Trait, na.rm = TRUE), 2), "\n")
cat("  % au-dessus seuil clinique (>46) =",
    round(mean(donnees$STAI_Trait > 46, na.rm = TRUE) * 100, 1), "%\n\n")

cat("CORRÉLATIONS SIGNIFICATIVES :\n")
for(i in seq_along(predicteurs)) {
  cor_res <- cor.test(donnees$STAI_Trait, donnees[[predicteurs[i]]])
  if(cor_res$p.value < 0.05) {
    cat(" ", labels_predicteurs[i], ": r =", round(cor_res$estimate, 3),
        ", p =", round(cor_res$p.value, 3), " ***\n")
  }
}

cat("\nCOMPARAISONS PAR GROUPES :\n")
cat("  Genre : p =", round(test_trait_genre$p.value, 3),
    ifelse(test_trait_genre$p.value < 0.05, " *** Différence",
           " (pas de différence)"), "\n")
cat("  Type de jeu : p =", round(test_trait_jeu$p.value, 3),
    ifelse(test_trait_jeu$p.value < 0.05, " *** Différence",
           " (pas de différence)"), "\n")
cat("  Fréquence : p =", round(test_trait_freq$p.value, 3),
    ifelse(test_trait_freq$p.value < 0.05, " *** Différence",
           " (pas de différence)"), "\n")
cat("  Âge (corrélation) : r =", round(cor_age_trait$estimate, 3),
    ", p =", round(cor_age_trait$p.value, 3),
    ifelse(cor_age_trait$p.value < 0.05, " ***",
           " (pas de différence)"), "\n\n")

cat("RÉGRESSION MULTIPLE :\n")
cat("  R² =", round(summary(modele_trait)$r.squared, 3), "\n")
cat("  R² ajusté =", round(summary(modele_trait)$adj.r.squared, 3), "\n\n")

cat("*** = p < 0.05 (significatif)\n")
cat("================================================================================\n")