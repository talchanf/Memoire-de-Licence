# ============================================================================
# ANALYSES APPROFONDIES : EFFETS DE L'ÂGE
# ============================================================================
library(readxl)
library(ggplot2)
library(dplyr)

# ===== CHARGEMENT =====
donnees_raw <- read_excel("tableau fin mémoire.xlsx")
donnees <- donnees_raw

colnames(donnees) <- c("ID", "Age", "Genre", "Type_jeu", "Type_joueur",
                       "Frequence", "Niveau_estime", "Niveau_reel",
                       "Toxicite_exposition", "Toxicite_impact",
                       "STAI_Etat", "STAI_Trait", "WHO5", "Rosenberg",
                       "Sommeil_latence", "Sommeil_difficulte",
                       "Sommeil_qualite", "Fatigue_ressenti")

# Conversion colonnes texte → scores numériques
donnees$Age <- case_when(
  grepl("16", donnees_raw[[2]]) ~ 1,
  grepl("18", donnees_raw[[2]]) ~ 2,
  grepl("22", donnees_raw[[2]]) ~ 3,
  grepl("26", donnees_raw[[2]]) ~ 4,
  grepl("31", donnees_raw[[2]]) ~ 5,
  TRUE ~ NA_real_
)

donnees$Sommeil_latence <- case_when(
  grepl("15min|15 min|égale à 15", donnees_raw[[15]])  ~ 1,
  grepl("16 à 30|16à30", donnees_raw[[15]])            ~ 2,
  grepl("31 à 60|31à60", donnees_raw[[15]])            ~ 3,
  grepl("Supérieur à 60|60min", donnees_raw[[15]])     ~ 4,
  TRUE ~ NA_real_
)

donnees$Sommeil_difficulte <- case_when(
  grepl("Pas au cours", donnees_raw[[16]])             ~ 0,
  grepl("Inférieur à 1", donnees_raw[[16]])            ~ 1,
  grepl("2 à 3 fois", donnees_raw[[16]])               ~ 2,
  grepl("3 à 4 fois", donnees_raw[[16]])               ~ 3,
  TRUE ~ NA_real_
)

# Conversion numérique
colonnes_num <- c("STAI_Etat", "STAI_Trait", "WHO5", "Rosenberg",
                  "Toxicite_exposition", "Toxicite_impact",
                  "Niveau_estime", "Niveau_reel",
                  "Sommeil_qualite", "Fatigue_ressenti", "Age")

for(col in colonnes_num) {
  donnees[[col]] <- as.numeric(donnees[[col]])
}

# Variables dérivées
donnees$Genre_clean <- factor(
  ifelse(grepl("Homme|homme", donnees$Genre), "Homme",
         ifelse(grepl("Femme|femme", donnees$Genre), "Femme", NA)),
  levels = c("Femme", "Homme")
)

donnees$Type_jeu_cat <- ifelse(
  grepl("Compétitif", donnees$Type_jeu) & !grepl("Non", donnees$Type_jeu),
  "Compétitif",
  ifelse(grepl("Non", donnees$Type_jeu), "Non-compétitif", "Les deux")
)

donnees$Freq_simple <- factor(
  ifelse(grepl("tous les jours", donnees$Frequence), "Quotidien", "Non-quotidien"),
  levels = c("Non-quotidien", "Quotidien")
)

# Groupes d'âge (médiane comme coupure)
mediane_age <- median(donnees$Age, na.rm = TRUE)
donnees$Age_groupe <- factor(
  ifelse(donnees$Age <= mediane_age, "Jeune", "Moins jeune"),
  levels = c("Jeune", "Moins jeune")
)

jeunes       <- donnees[donnees$Age_groupe == "Jeune" & !is.na(donnees$Age_groupe), ]
moins_jeunes <- donnees[donnees$Age_groupe == "Moins jeune" & !is.na(donnees$Age_groupe), ]

table(donnees$Age_groupe)

cat("================================================================================\n")
cat("ANALYSES APPROFONDIES SUR L'ÂGE\n")
cat("================================================================================\n")
cat("N total =", nrow(donnees), "participants\n")
cat("Age moyen =", round(mean(donnees$Age, na.rm = TRUE), 2), "\n")
cat("Age médian =", mediane_age, "\n")
cat("Age min =", min(donnees$Age, na.rm = TRUE), "\n")
cat("Age max =", max(donnees$Age, na.rm = TRUE), "\n")
cat("Jeunes (<=", mediane_age, "ans) =", sum(donnees$Age_groupe == "Jeune", na.rm = TRUE), "\n")
cat("Moins jeunes (>", mediane_age, "ans) =", sum(donnees$Age_groupe == "Moins jeune", na.rm = TRUE), "\n\n")

# ============================================================================
# 1. ÂGE → SANTÉ MENTALE (CORRÉLATIONS)
# ============================================================================

cat("================================================================================\n")
cat("1. ÂGE → SANTÉ MENTALE (CORRÉLATIONS)\n")
cat("================================================================================\n\n")

variables_sante <- c("STAI_Etat", "STAI_Trait", "WHO5", "Rosenberg")
labels_sante    <- c("Anxiété-État", "Anxiété-Trait", "Bien-être (WHO-5)", "Estime de soi")

cat("Corrélations Age → Santé mentale :\n")
cat("------------------------------------\n")
for(i in seq_along(variables_sante)) {
  cor_res <- cor.test(donnees$Age, donnees[[variables_sante[i]]])
  cat(labels_sante[i], ": r =", round(cor_res$estimate, 3),
      ", p =", round(cor_res$p.value, 3),
      ifelse(cor_res$p.value < 0.05, " ***", ""), "\n")
}

# Graphiques corrélations
par(mfrow = c(2, 2))
for(i in seq_along(variables_sante)) {
  plot(donnees$Age, donnees[[variables_sante[i]]],
       pch = 19, col = rgb(0.2, 0.4, 0.8, 0.5), cex = 1.5,
       xlab = "Âge",
       ylab = labels_sante[i],
       main = paste0("Âge → ", labels_sante[i]))
  abline(lm(donnees[[variables_sante[i]]] ~ donnees$Age),
         col = "blue", lwd = 2)
}
par(mfrow = c(1, 1))

# ============================================================================
# 2. ÂGE → SANTÉ MENTALE (GROUPES)
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("2. SANTÉ MENTALE SELON LE GROUPE D'ÂGE\n")
cat("================================================================================\n\n")

stats_age_base <- donnees %>%
  group_by(Age_groupe) %>%
  summarise(
    N = n(),
    M_Age        = mean(Age, na.rm = TRUE),
    M_STAI_Etat  = mean(STAI_Etat, na.rm = TRUE),
    ET_STAI_Etat = sd(STAI_Etat, na.rm = TRUE),
    M_STAI_Trait  = mean(STAI_Trait, na.rm = TRUE),
    ET_STAI_Trait = sd(STAI_Trait, na.rm = TRUE),
    M_WHO5  = mean(WHO5, na.rm = TRUE),
    ET_WHO5 = sd(WHO5, na.rm = TRUE),
    M_Rosenberg  = mean(Rosenberg, na.rm = TRUE),
    ET_Rosenberg = sd(Rosenberg, na.rm = TRUE),
    .groups = "drop"
  )

stats_age_base %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

cat("\nTests t (Jeune vs Moins jeune) :\n")
cat("----------------------------------\n")

test_age_etat      <- t.test(STAI_Etat ~ Age_groupe, data = donnees)
test_age_trait     <- t.test(STAI_Trait ~ Age_groupe, data = donnees)
test_age_who5      <- t.test(WHO5 ~ Age_groupe, data = donnees)
test_age_rosenberg <- t.test(Rosenberg ~ Age_groupe, data = donnees)

cat("Anxiété-État : t =", round(test_age_etat$statistic, 3),
    ", p =", round(test_age_etat$p.value, 3),
    ifelse(test_age_etat$p.value < 0.05, " ***", ""), "\n")
cat("Anxiété-Trait : t =", round(test_age_trait$statistic, 3),
    ", p =", round(test_age_trait$p.value, 3),
    ifelse(test_age_trait$p.value < 0.05, " ***", ""), "\n")
cat("Bien-être : t =", round(test_age_who5$statistic, 3),
    ", p =", round(test_age_who5$p.value, 3),
    ifelse(test_age_who5$p.value < 0.05, " ***", ""), "\n")
cat("Estime de soi : t =", round(test_age_rosenberg$statistic, 3),
    ", p =", round(test_age_rosenberg$p.value, 3),
    ifelse(test_age_rosenberg$p.value < 0.05, " ***", ""), "\n")

par(mfrow = c(2, 2))
boxplot(STAI_Etat ~ Age_groupe, data = donnees,
        main = paste0("Anxiété-État\np = ", round(test_age_etat$p.value, 3)),
        col = c("lightyellow", "lightcoral"), ylab = "STAI-État")
boxplot(STAI_Trait ~ Age_groupe, data = donnees,
        main = paste0("Anxiété-Trait\np = ", round(test_age_trait$p.value, 3)),
        col = c("lightyellow", "lightcoral"), ylab = "STAI-Trait")
boxplot(WHO5 ~ Age_groupe, data = donnees,
        main = paste0("Bien-être\np = ", round(test_age_who5$p.value, 3)),
        col = c("lightyellow", "lightcoral"), ylab = "WHO-5")
boxplot(Rosenberg ~ Age_groupe, data = donnees,
        main = paste0("Estime de soi\np = ", round(test_age_rosenberg$p.value, 3)),
        col = c("lightyellow", "lightcoral"), ylab = "Rosenberg")
par(mfrow = c(1, 1))

# ============================================================================
# 3. ÂGE × TYPE DE JEU → ANXIÉTÉ
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("3. ÂGE × TYPE DE JEU → ANXIÉTÉ\n")
cat("================================================================================\n\n")

cat("Question : Les joueurs plus âgés en compétitif sont-ils plus anxieux ?\n\n")

donnees_h3 <- donnees[donnees$Type_jeu_cat != "Les deux", ]

cat("Répartition Âge × Type de jeu :\n")
print(table(donnees_h3$Age_groupe, donnees_h3$Type_jeu_cat))

moyennes_h3 <- donnees_h3 %>%
  group_by(Age_groupe, Type_jeu_cat) %>%
  summarise(
    n = n(),
    M_anxiete  = mean(STAI_Etat, na.rm = TRUE),
    ET_anxiete = sd(STAI_Etat, na.rm = TRUE),
    .groups = "drop"
  )

cat("\nMoyennes Anxiété-État :\n")
moyennes_h3 %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

anova_h3 <- aov(STAI_Etat ~ Age_groupe * Type_jeu_cat, data = donnees_h3)
cat("\nANOVA Âge × Type de jeu :\n")
print(summary(anova_h3))

ggplot(moyennes_h3, aes(x = Type_jeu_cat, y = M_anxiete,
                        color = Age_groupe, group = Age_groupe)) +
  geom_line(linewidth = 2) +
  geom_point(size = 5) +
  labs(title = "Interaction Âge × Type de jeu → Anxiété",
       x = "Type de jeu", y = "Anxiété-État moyenne",
       color = "Groupe d'âge") +
  theme_minimal() +
  scale_color_manual(values = c("Jeune" = "lightyellow3", "Moins jeune" = "lightcoral"))

# ============================================================================
# 4. ÂGE × TOXICITÉ
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("4. ÂGE × TOXICITÉ\n")
cat("================================================================================\n\n")

cat("Question : Les joueurs plus âgés sont-ils plus ou moins exposés à la toxicité ?\n\n")

# Corrélations Age → Toxicité
cor_age_exp <- cor.test(donnees$Age, donnees$Toxicite_exposition)
cor_age_imp <- cor.test(donnees$Age, donnees$Toxicite_impact)

cat("Corrélations Age → Toxicité :\n")
cat("  Exposition : r =", round(cor_age_exp$estimate, 3),
    ", p =", round(cor_age_exp$p.value, 3),
    ifelse(cor_age_exp$p.value < 0.05, " ***", ""), "\n")
cat("  Impact : r =", round(cor_age_imp$estimate, 3),
    ", p =", round(cor_age_imp$p.value, 3),
    ifelse(cor_age_imp$p.value < 0.05, " ***", ""), "\n")

stats_tox_age <- donnees %>%
  group_by(Age_groupe) %>%
  summarise(
    n = n(),
    M_exposition  = mean(Toxicite_exposition, na.rm = TRUE),
    ET_exposition = sd(Toxicite_exposition, na.rm = TRUE),
    M_impact      = mean(Toxicite_impact, na.rm = TRUE),
    ET_impact     = sd(Toxicite_impact, na.rm = TRUE),
    .groups = "drop"
  )

cat("\nToxicité par groupe d'âge :\n")
stats_tox_age %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_age_tox_exp <- t.test(Toxicite_exposition ~ Age_groupe, data = donnees)
test_age_tox_imp <- t.test(Toxicite_impact ~ Age_groupe, data = donnees)

cat("\nTests t :\n")
cat("  Exposition : t =", round(test_age_tox_exp$statistic, 3),
    ", p =", round(test_age_tox_exp$p.value, 3),
    ifelse(test_age_tox_exp$p.value < 0.05, " ***", ""), "\n")
cat("  Impact : t =", round(test_age_tox_imp$statistic, 3),
    ", p =", round(test_age_tox_imp$p.value, 3),
    ifelse(test_age_tox_imp$p.value < 0.05, " ***", ""), "\n")

# Corrélations Toxicité → Anxiété par groupe d'âge
cor_j_imp  <- cor.test(jeunes$Toxicite_impact, jeunes$STAI_Etat)
cor_mj_imp <- cor.test(moins_jeunes$Toxicite_impact, moins_jeunes$STAI_Etat)

cat("\nCorrélations Impact toxicité → Anxiété par groupe d'âge :\n")
cat("  Jeunes : r =", round(cor_j_imp$estimate, 3),
    ", p =", round(cor_j_imp$p.value, 3),
    ifelse(cor_j_imp$p.value < 0.05, " ***", ""), "\n")
cat("  Moins jeunes : r =", round(cor_mj_imp$estimate, 3),
    ", p =", round(cor_mj_imp$p.value, 3),
    ifelse(cor_mj_imp$p.value < 0.05, " ***", ""), "\n")

par(mfrow = c(1, 2))
boxplot(Toxicite_exposition ~ Age_groupe, data = donnees,
        main = paste0("Exposition toxicité\npar âge\np = ",
                      round(test_age_tox_exp$p.value, 3)),
        col = c("lightyellow", "lightcoral"), ylab = "Score d'exposition")
boxplot(Toxicite_impact ~ Age_groupe, data = donnees,
        main = paste0("Impact émotionnel\npar âge\np = ",
                      round(test_age_tox_imp$p.value, 3)),
        col = c("lightyellow", "lightcoral"), ylab = "Score d'impact")
par(mfrow = c(1, 1))

# ============================================================================
# 5. ÂGE × SOMMEIL
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("5. ÂGE × QUALITÉ DU SOMMEIL\n")
cat("================================================================================\n\n")

cat("Question : Les joueurs plus âgés dorment-ils différemment ?\n\n")

# Corrélations Age → Sommeil
cor_age_qualite   <- cor.test(donnees$Age, donnees$Sommeil_qualite)
cor_age_latence   <- cor.test(donnees$Age, donnees$Sommeil_latence)
cor_age_difficulte <- cor.test(donnees$Age, donnees$Sommeil_difficulte)

cat("Corrélations Age → Sommeil :\n")
cat("  Qualité : r =", round(cor_age_qualite$estimate, 3),
    ", p =", round(cor_age_qualite$p.value, 3),
    ifelse(cor_age_qualite$p.value < 0.05, " ***", ""), "\n")
cat("  Latence : r =", round(cor_age_latence$estimate, 3),
    ", p =", round(cor_age_latence$p.value, 3),
    ifelse(cor_age_latence$p.value < 0.05, " ***", ""), "\n")
cat("  Difficultés : r =", round(cor_age_difficulte$estimate, 3),
    ", p =", round(cor_age_difficulte$p.value, 3),
    ifelse(cor_age_difficulte$p.value < 0.05, " ***", ""), "\n")

stats_sommeil_age <- donnees %>%
  group_by(Age_groupe) %>%
  summarise(
    n = n(),
    M_qualite    = mean(Sommeil_qualite, na.rm = TRUE),
    ET_qualite   = sd(Sommeil_qualite, na.rm = TRUE),
    M_latence    = mean(Sommeil_latence, na.rm = TRUE),
    M_difficulte = mean(Sommeil_difficulte, na.rm = TRUE),
    .groups = "drop"
  )

cat("\nQualité du sommeil par groupe d'âge :\n")
stats_sommeil_age %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_age_sommeil    <- t.test(Sommeil_qualite ~ Age_groupe, data = donnees)
test_age_latence    <- t.test(Sommeil_latence ~ Age_groupe, data = donnees)
test_age_difficulte <- t.test(Sommeil_difficulte ~ Age_groupe, data = donnees)

cat("\nTests t :\n")
cat("  Qualité : t =", round(test_age_sommeil$statistic, 3),
    ", p =", round(test_age_sommeil$p.value, 3),
    ifelse(test_age_sommeil$p.value < 0.05, " ***", ""), "\n")
cat("  Latence : t =", round(test_age_latence$statistic, 3),
    ", p =", round(test_age_latence$p.value, 3),
    ifelse(test_age_latence$p.value < 0.05, " ***", ""), "\n")
cat("  Difficultés : t =", round(test_age_difficulte$statistic, 3),
    ", p =", round(test_age_difficulte$p.value, 3),
    ifelse(test_age_difficulte$p.value < 0.05, " ***", ""), "\n")

# Corrélations Sommeil → Anxiété par groupe d'âge
cor_j_sommeil  <- cor.test(jeunes$Sommeil_qualite, jeunes$STAI_Etat)
cor_mj_sommeil <- cor.test(moins_jeunes$Sommeil_qualite, moins_jeunes$STAI_Etat)

cat("\nCorrélations Sommeil → Anxiété par groupe d'âge :\n")
cat("  Jeunes : r =", round(cor_j_sommeil$estimate, 3),
    ", p =", round(cor_j_sommeil$p.value, 3),
    ifelse(cor_j_sommeil$p.value < 0.05, " ***", ""), "\n")
cat("  Moins jeunes : r =", round(cor_mj_sommeil$estimate, 3),
    ", p =", round(cor_mj_sommeil$p.value, 3),
    ifelse(cor_mj_sommeil$p.value < 0.05, " ***", ""), "\n")

boxplot(Sommeil_qualite ~ Age_groupe, data = donnees,
        main = paste0("Qualité du sommeil par groupe d'âge\np = ",
                      round(test_age_sommeil$p.value, 3)),
        col = c("lightyellow", "lightcoral"),
        ylab = "Qualité du sommeil (1-5)")

# ============================================================================
# 6. ÂGE × PERCEPTION DU NIVEAU
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("6. ÂGE × PERCEPTION DU NIVEAU\n")
cat("================================================================================\n\n")

cat("Question : Les joueurs plus âgés se perçoivent-ils mieux ?\n\n")

donnees$Ecart_niveau <- donnees$Niveau_reel - donnees$Niveau_estime

# Corrélations Age → Niveau
cor_age_estime <- cor.test(donnees$Age, donnees$Niveau_estime)
cor_age_reel   <- cor.test(donnees$Age, donnees$Niveau_reel)
cor_age_ecart  <- cor.test(donnees$Age, donnees$Ecart_niveau)

cat("Corrélations Age → Perception du niveau :\n")
cat("  Niveau estimé : r =", round(cor_age_estime$estimate, 3),
    ", p =", round(cor_age_estime$p.value, 3),
    ifelse(cor_age_estime$p.value < 0.05, " ***", ""), "\n")
cat("  Niveau réel : r =", round(cor_age_reel$estimate, 3),
    ", p =", round(cor_age_reel$p.value, 3),
    ifelse(cor_age_reel$p.value < 0.05, " ***", ""), "\n")
cat("  Écart : r =", round(cor_age_ecart$estimate, 3),
    ", p =", round(cor_age_ecart$p.value, 3),
    ifelse(cor_age_ecart$p.value < 0.05, " ***", ""), "\n")

stats_niveau_age <- donnees %>%
  group_by(Age_groupe) %>%
  summarise(
    n = n(),
    M_ecart  = mean(Ecart_niveau, na.rm = TRUE),
    ET_ecart = sd(Ecart_niveau, na.rm = TRUE),
    M_estime = mean(Niveau_estime, na.rm = TRUE),
    M_reel   = mean(Niveau_reel, na.rm = TRUE),
    .groups = "drop"
  )

cat("\nPerception du niveau par groupe d'âge :\n")
stats_niveau_age %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_age_estime <- t.test(Niveau_estime ~ Age_groupe, data = donnees)
test_age_reel   <- t.test(Niveau_reel ~ Age_groupe, data = donnees)
test_age_ecart  <- t.test(Ecart_niveau ~ Age_groupe, data = donnees)

cat("\nTests t :\n")
cat("  Niveau estimé : t =", round(test_age_estime$statistic, 3),
    ", p =", round(test_age_estime$p.value, 3),
    ifelse(test_age_estime$p.value < 0.05, " ***", ""), "\n")
cat("  Niveau réel : t =", round(test_age_reel$statistic, 3),
    ", p =", round(test_age_reel$p.value, 3),
    ifelse(test_age_reel$p.value < 0.05, " ***", ""), "\n")
cat("  Écart : t =", round(test_age_ecart$statistic, 3),
    ", p =", round(test_age_ecart$p.value, 3),
    ifelse(test_age_ecart$p.value < 0.05, " ***", ""), "\n")

cat("\nInterprétation :\n")
cat("  Écart > 0 = Surestimation\n")
cat("  Écart < 0 = Sous-estimation\n")

# ============================================================================
# RÉSUMÉ FINAL ÂGE
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("RÉSUMÉ : EFFETS DE L'ÂGE\n")
cat("================================================================================\n\n")

cat("CORRÉLATIONS AGE → SANTÉ MENTALE :\n")
for(i in seq_along(variables_sante)) {
  cor_res <- cor.test(donnees$Age, donnees[[variables_sante[i]]])
  cat(" ", labels_sante[i], ": r =", round(cor_res$estimate, 3),
      ", p =", round(cor_res$p.value, 3),
      ifelse(cor_res$p.value < 0.05, " ***", " (non sig.)"), "\n")
}

cat("\nSANTÉ MENTALE PAR GROUPE D'ÂGE :\n")
cat("  Anxiété-État : p =", round(test_age_etat$p.value, 3),
    ifelse(test_age_etat$p.value < 0.05, " *** Différence",
           " (pas de différence)"), "\n")
cat("  Anxiété-Trait : p =", round(test_age_trait$p.value, 3),
    ifelse(test_age_trait$p.value < 0.05, " ***",
           " (pas de différence)"), "\n")
cat("  Bien-être : p =", round(test_age_who5$p.value, 3),
    ifelse(test_age_who5$p.value < 0.05, " ***",
           " (pas de différence)"), "\n")
cat("  Estime de soi : p =", round(test_age_rosenberg$p.value, 3),
    ifelse(test_age_rosenberg$p.value < 0.05, " ***",
           " (pas de différence)"), "\n\n")

cat("TOXICITÉ :\n")
cat("  Exposition : p =", round(test_age_tox_exp$p.value, 3),
    ifelse(test_age_tox_exp$p.value < 0.05, " *** Différence",
           " (pas de différence)"), "\n")
cat("  Impact : p =", round(test_age_tox_imp$p.value, 3),
    ifelse(test_age_tox_imp$p.value < 0.05, " ***",
           " (pas de différence)"), "\n\n")

cat("SOMMEIL :\n")
cat("  Qualité : p =", round(test_age_sommeil$p.value, 3),
    ifelse(test_age_sommeil$p.value < 0.05, " ***",
           " (pas de différence)"), "\n")
cat("  Latence : p =", round(test_age_latence$p.value, 3),
    ifelse(test_age_latence$p.value < 0.05, " ***",
           " (pas de différence)"), "\n")
cat("  Difficultés : p =", round(test_age_difficulte$p.value, 3),
    ifelse(test_age_difficulte$p.value < 0.05, " ***",
           " (pas de différence)"), "\n\n")

cat("PERCEPTION DU NIVEAU :\n")
cat("  Niveau estimé : p =", round(test_age_estime$p.value, 3),
    ifelse(test_age_estime$p.value < 0.05, " *** Différence",
           " (pas de différence)"), "\n")
cat("  Niveau réel : p =", round(test_age_reel$p.value, 3),
    ifelse(test_age_reel$p.value < 0.05, " ***",
           " (pas de différence)"), "\n")
cat("  Écart : p =", round(test_age_ecart$p.value, 3),
    ifelse(test_age_ecart$p.value < 0.05, " ***",
           " (pas de différence)"), "\n\n")

cat("*** = p < 0.05 (significatif)\n")
cat("================================================================================\n")