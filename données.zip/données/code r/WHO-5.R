# ============================================================================
# ANALYSES APPROFONDIES : WHO-5 (BIEN-ÊTRE)
# ============================================================================
library(readxl)
library(ggplot2)
library(dplyr)

# ===== CHARGEMENT =====
donnees_raw <- read_excel("tableau fin mémoire.xlsx")
donnees <- donnees_raw

colnames(donnees) <- c("ID", "Age", "Genre", "Type_jeu", "Type_joueur",
                       "Frequence", "Niveau_estime", "Niveau_reel",
                       "Toxicite_exposition", "Toxicite_impact",
                       "STAI_Etat", "STAI_Trait", "WHO5", "Rosenberg",
                       "Sommeil_latence", "Sommeil_difficulte",
                       "Sommeil_qualite", "Fatigue_ressenti")

# Conversion colonnes texte → scores numériques
donnees$Sommeil_latence <- case_when(
  grepl("15min|15 min|égale à 15", donnees_raw[[15]])  ~ 1,
  grepl("16 à 30|16à30", donnees_raw[[15]])            ~ 2,
  grepl("31 à 60|31à60", donnees_raw[[15]])            ~ 3,
  grepl("Supérieur à 60|60min", donnees_raw[[15]])     ~ 4,
  TRUE ~ NA_real_
)

donnees$Sommeil_difficulte <- case_when(
  grepl("Pas au cours", donnees_raw[[16]])             ~ 0,
  grepl("Inférieur à 1", donnees_raw[[16]])            ~ 1,
  grepl("2 à 3 fois", donnees_raw[[16]])               ~ 2,
  grepl("3 à 4 fois", donnees_raw[[16]])               ~ 3,
  TRUE ~ NA_real_
)

donnees$Age <- case_when(
  grepl("16", donnees_raw[[2]]) ~ 1,
  grepl("18", donnees_raw[[2]]) ~ 2,
  grepl("22", donnees_raw[[2]]) ~ 3,
  grepl("26", donnees_raw[[2]]) ~ 4,
  grepl("31", donnees_raw[[2]]) ~ 5,
  TRUE ~ NA_real_
)

# Conversion numérique
colonnes_num <- c("STAI_Etat", "STAI_Trait", "WHO5", "Rosenberg",
                  "Toxicite_exposition", "Toxicite_impact",
                  "Niveau_estime", "Niveau_reel",
                  "Sommeil_qualite", "Fatigue_ressenti")

for(col in colonnes_num) {
  donnees[[col]] <- as.numeric(donnees[[col]])
}

# Variables dérivées
donnees$Genre_clean <- factor(
  ifelse(grepl("Homme|homme", donnees$Genre), "Homme",
         ifelse(grepl("Femme|femme", donnees$Genre), "Femme", NA)),
  levels = c("Femme", "Homme")
)

donnees$Type_jeu_cat <- ifelse(
  grepl("Compétitif", donnees$Type_jeu) & !grepl("Non", donnees$Type_jeu),
  "Compétitif",
  ifelse(grepl("Non", donnees$Type_jeu), "Non-compétitif", "Les deux")
)

donnees$Freq_simple <- factor(
  ifelse(grepl("tous les jours", donnees$Frequence), "Quotidien", "Non-quotidien"),
  levels = c("Non-quotidien", "Quotidien")
)

donnees$Age_cat <- factor(donnees$Age,
                          labels = c("16-18", "18-21", "22-25", "26-30", "31+"))

# Sous-groupes
donnees_genre <- donnees[!is.na(donnees$Genre_clean), ]

cat("================================================================================\n")
cat("ANALYSES APPROFONDIES : WHO-5 (BIEN-ÊTRE)\n")
cat("================================================================================\n")
cat("N total =", nrow(donnees), "participants\n")
cat("M WHO-5 =", round(mean(donnees$WHO5, na.rm = TRUE), 2), "\n")
cat("ET WHO-5 =", round(sd(donnees$WHO5, na.rm = TRUE), 2), "\n")
cat("Min =", min(donnees$WHO5, na.rm = TRUE), "\n")
cat("Max =", max(donnees$WHO5, na.rm = TRUE), "\n\n")

# ============================================================================
# 1. DESCRIPTION DU BIEN-ÊTRE
# ============================================================================

cat("================================================================================\n")
cat("1. DESCRIPTION DU BIEN-ÊTRE (WHO-5)\n")
cat("================================================================================\n\n")

hist(donnees$WHO5,
     main = "Distribution du WHO-5",
     xlab = "Score WHO-5",
     col = "lightgreen", border = "darkgreen",
     breaks = 10)
abline(v = mean(donnees$WHO5, na.rm = TRUE), col = "red", lwd = 2, lty = 2)
legend("topright", legend = paste0("Moyenne = ",
                                   round(mean(donnees$WHO5, na.rm = TRUE), 1)),
       col = "red", lty = 2, lwd = 2)

# Seuil clinique WHO-5 (score <= 50 sur 100 = risque de dépression)
# Note : si ton WHO-5 est sur 25, le seuil est <= 12
cat("Seuil clinique (score <= 50) :\n")
cat("  N en-dessous du seuil =", sum(donnees$WHO5 <= 50, na.rm = TRUE), "\n")
cat("  % en-dessous du seuil =",
    round(mean(donnees$WHO5 <= 50, na.rm = TRUE) * 100, 1), "%\n\n")

# ============================================================================
# 2. CORRÉLATIONS : FACTEURS ASSOCIÉS AU BIEN-ÊTRE
# ============================================================================

cat("================================================================================\n")
cat("2. FACTEURS ASSOCIÉS AU BIEN-ÊTRE (CORRÉLATIONS)\n")
cat("================================================================================\n\n")

predicteurs        <- c("STAI_Etat", "STAI_Trait", "Rosenberg",
                        "Toxicite_exposition", "Toxicite_impact",
                        "Sommeil_qualite", "Sommeil_latence", "Sommeil_difficulte",
                        "Fatigue_ressenti", "Niveau_estime", "Niveau_reel", "Age")
labels_predicteurs <- c("Anxiété-État", "Anxiété-Trait", "Estime de soi",
                        "Exposition toxicité", "Impact toxicité",
                        "Qualité sommeil", "Latence sommeil", "Difficultés sommeil",
                        "Fatigue ressentie", "Niveau estimé", "Niveau réel", "Âge")

cat("Corrélations avec WHO-5 :\n")
cat("--------------------------\n")
for(i in seq_along(predicteurs)) {
  cor_res <- cor.test(donnees$WHO5, donnees[[predicteurs[i]]])
  cat(labels_predicteurs[i], ": r =", round(cor_res$estimate, 3),
      ", p =", round(cor_res$p.value, 3),
      ifelse(cor_res$p.value < 0.05, " ***", ""), "\n")
}

# Graphiques des corrélations significatives
par(mfrow = c(2, 3))
for(i in seq_along(predicteurs)) {
  cor_res <- cor.test(donnees$WHO5, donnees[[predicteurs[i]]])
  if(cor_res$p.value < 0.05) {
    plot(donnees[[predicteurs[i]]], donnees$WHO5,
         pch = 19, col = rgb(0.2, 0.6, 0.2, 0.5), cex = 1.5,
         xlab = labels_predicteurs[i],
         ylab = "WHO-5",
         main = paste0(labels_predicteurs[i], "\nr = ",
                       round(cor_res$estimate, 3),
                       ", p = ", round(cor_res$p.value, 3)))
    abline(lm(donnees$WHO5 ~ donnees[[predicteurs[i]]]),
           col = "darkgreen", lwd = 2)
  }
}
par(mfrow = c(1, 1))

# ============================================================================
# 3. RÉGRESSION MULTIPLE
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("3. RÉGRESSION MULTIPLE : QUELS FACTEURS PRÉDISENT LE BIEN-ÊTRE ?\n")
cat("================================================================================\n\n")

modele_who5 <- lm(WHO5 ~ STAI_Etat + STAI_Trait + Rosenberg +
                    Toxicite_exposition + Toxicite_impact +
                    Sommeil_qualite + Fatigue_ressenti,
                  data = donnees)

cat("Modèle de régression multiple :\n")
print(summary(modele_who5))

cat("\nVariance expliquée (R²) =",
    round(summary(modele_who5)$r.squared, 3), "\n")
cat("R² ajusté =",
    round(summary(modele_who5)$adj.r.squared, 3), "\n")

# ============================================================================
# 4. BIEN-ÊTRE SELON LE GENRE
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("4. BIEN-ÊTRE SELON LE GENRE\n")
cat("================================================================================\n\n")

stats_who5_genre <- donnees_genre %>%
  group_by(Genre_clean) %>%
  summarise(
    n = n(),
    M_WHO5  = mean(WHO5, na.rm = TRUE),
    ET_WHO5 = sd(WHO5, na.rm = TRUE),
    Min = min(WHO5, na.rm = TRUE),
    Max = max(WHO5, na.rm = TRUE),
    .groups = "drop"
  )

stats_who5_genre %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_who5_genre <- t.test(WHO5 ~ Genre_clean, data = donnees_genre)
cat("\nTest t : t =", round(test_who5_genre$statistic, 3),
    ", p =", round(test_who5_genre$p.value, 3),
    ifelse(test_who5_genre$p.value < 0.05, " ***", ""), "\n")

boxplot(WHO5 ~ Genre_clean, data = donnees_genre,
        main = paste0("Bien-être par genre\np = ",
                      round(test_who5_genre$p.value, 3)),
        col = c("pink", "lightblue"), ylab = "WHO-5")

# ============================================================================
# 5. BIEN-ÊTRE SELON LE TYPE DE JEU
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("5. BIEN-ÊTRE SELON LE TYPE DE JEU\n")
cat("================================================================================\n\n")

donnees_h5 <- donnees[donnees$Type_jeu_cat != "Les deux", ]
donnees_h5$Type_jeu_cat <- factor(donnees_h5$Type_jeu_cat,
                                  levels = c("Non-compétitif", "Compétitif"))

stats_who5_jeu <- donnees_h5 %>%
  group_by(Type_jeu_cat) %>%
  summarise(
    n = n(),
    M_WHO5  = mean(WHO5, na.rm = TRUE),
    ET_WHO5 = sd(WHO5, na.rm = TRUE),
    Min = min(WHO5, na.rm = TRUE),
    Max = max(WHO5, na.rm = TRUE),
    .groups = "drop"
  )

stats_who5_jeu %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_who5_jeu <- t.test(WHO5 ~ Type_jeu_cat, data = donnees_h5)
cat("\nTest t : t =", round(test_who5_jeu$statistic, 3),
    ", p =", round(test_who5_jeu$p.value, 3),
    ifelse(test_who5_jeu$p.value < 0.05, " ***", ""), "\n")

boxplot(WHO5 ~ Type_jeu_cat, data = donnees_h5,
        main = paste0("Bien-être par type de jeu\np = ",
                      round(test_who5_jeu$p.value, 3)),
        col = c("lightgreen", "lightyellow"), ylab = "WHO-5")

# ============================================================================
# 6. BIEN-ÊTRE SELON LA FRÉQUENCE DE JEU
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("6. BIEN-ÊTRE SELON LA FRÉQUENCE DE JEU\n")
cat("================================================================================\n\n")

stats_who5_freq <- donnees %>%
  group_by(Freq_simple) %>%
  summarise(
    n = n(),
    M_WHO5  = mean(WHO5, na.rm = TRUE),
    ET_WHO5 = sd(WHO5, na.rm = TRUE),
    Min = min(WHO5, na.rm = TRUE),
    Max = max(WHO5, na.rm = TRUE),
    .groups = "drop"
  )

stats_who5_freq %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_who5_freq <- t.test(WHO5 ~ Freq_simple, data = donnees)
cat("\nTest t : t =", round(test_who5_freq$statistic, 3),
    ", p =", round(test_who5_freq$p.value, 3),
    ifelse(test_who5_freq$p.value < 0.05, " ***", ""), "\n")

boxplot(WHO5 ~ Freq_simple, data = donnees,
        main = paste0("Bien-être par fréquence\np = ",
                      round(test_who5_freq$p.value, 3)),
        col = c("lightgreen", "lightyellow"), ylab = "WHO-5")

# ============================================================================
# 7. BIEN-ÊTRE SELON L'ÂGE
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("7. BIEN-ÊTRE SELON L'ÂGE\n")
cat("================================================================================\n\n")

stats_who5_age <- donnees %>%
  group_by(Age_cat) %>%
  summarise(
    n = n(),
    M_WHO5  = mean(WHO5, na.rm = TRUE),
    ET_WHO5 = sd(WHO5, na.rm = TRUE),
    .groups = "drop"
  )

stats_who5_age %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

anova_who5_age <- aov(WHO5 ~ Age_cat, data = donnees)
cat("\nANOVA Âge → Bien-être :\n")
print(summary(anova_who5_age))

cor_age_who5 <- cor.test(donnees$Age, donnees$WHO5)
cat("\nCorrélation Age → Bien-être : r =", round(cor_age_who5$estimate, 3),
    ", p =", round(cor_age_who5$p.value, 3),
    ifelse(cor_age_who5$p.value < 0.05, " ***", ""), "\n")

boxplot(WHO5 ~ Age_cat, data = donnees,
        main = "Bien-être par tranche d'âge",
        col = "lightgreen", ylab = "WHO-5")

# ============================================================================
# RÉSUMÉ FINAL WHO-5
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("RÉSUMÉ : FACTEURS ASSOCIÉS AU BIEN-ÊTRE (WHO-5)\n")
cat("================================================================================\n\n")

cat("DESCRIPTION :\n")
cat("  Moyenne =", round(mean(donnees$WHO5, na.rm = TRUE), 2), "\n")
cat("  ET =", round(sd(donnees$WHO5, na.rm = TRUE), 2), "\n")
cat("  % en-dessous seuil clinique (<=50) =",
    round(mean(donnees$WHO5 <= 50, na.rm = TRUE) * 100, 1), "%\n\n")

cat("CORRÉLATIONS SIGNIFICATIVES :\n")
for(i in seq_along(predicteurs)) {
  cor_res <- cor.test(donnees$WHO5, donnees[[predicteurs[i]]])
  if(cor_res$p.value < 0.05) {
    cat(" ", labels_predicteurs[i], ": r =", round(cor_res$estimate, 3),
        ", p =", round(cor_res$p.value, 3), " ***\n")
  }
}

cat("\nCOMPARAISONS PAR GROUPES :\n")
cat("  Genre : p =", round(test_who5_genre$p.value, 3),
    ifelse(test_who5_genre$p.value < 0.05, " *** Différence",
           " (pas de différence)"), "\n")
cat("  Type de jeu : p =", round(test_who5_jeu$p.value, 3),
    ifelse(test_who5_jeu$p.value < 0.05, " *** Différence",
           " (pas de différence)"), "\n")
cat("  Fréquence : p =", round(test_who5_freq$p.value, 3),
    ifelse(test_who5_freq$p.value < 0.05, " *** Différence",
           " (pas de différence)"), "\n")
cat("  Âge (corrélation) : r =", round(cor_age_who5$estimate, 3),
    ", p =", round(cor_age_who5$p.value, 3),
    ifelse(cor_age_who5$p.value < 0.05, " ***",
           " (pas de différence)"), "\n\n")

cat("RÉGRESSION MULTIPLE :\n")
cat("  R² =", round(summary(modele_who5)$r.squared, 3), "\n")
cat("  R² ajusté =", round(summary(modele_who5)$adj.r.squared, 3), "\n\n")

cat("*** = p < 0.05 (significatif)\n")
cat("================================================================================\n")
