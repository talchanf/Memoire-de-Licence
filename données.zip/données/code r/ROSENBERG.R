# ============================================================================
# ANALYSES APPROFONDIES : ÉCHELLE DE ROSENBERG (ESTIME DE SOI)
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("ANALYSES APPROFONDIES : ÉCHELLE DE ROSENBERG (ESTIME DE SOI)\n")
cat("================================================================================\n")
cat("N total =", nrow(donnees), "participants\n")
cat("M Rosenberg =", round(mean(donnees$Rosenberg, na.rm = TRUE), 2), "\n")
cat("ET Rosenberg =", round(sd(donnees$Rosenberg, na.rm = TRUE), 2), "\n")
cat("Min =", min(donnees$Rosenberg, na.rm = TRUE), "\n")
cat("Max =", max(donnees$Rosenberg, na.rm = TRUE), "\n\n")

# ============================================================================
# 1. DESCRIPTION DE L'ESTIME DE SOI
# ============================================================================

cat("================================================================================\n")
cat("1. DESCRIPTION DE L'ESTIME DE SOI (ROSENBERG)\n")
cat("================================================================================\n\n")

hist(donnees$Rosenberg,
     main = "Distribution de l'Échelle de Rosenberg",
     xlab = "Score Rosenberg",
     col = "lightsalmon", border = "darkorange",
     breaks = 10)
abline(v = mean(donnees$Rosenberg, na.rm = TRUE), col = "red", lwd = 2, lty = 2)
legend("topright", legend = paste0("Moyenne = ",
                                   round(mean(donnees$Rosenberg, na.rm = TRUE), 1)),
       col = "red", lty = 2, lwd = 2)

# Seuil faible estime de soi (score < 15 sur 30 = faible estime)
cat("Seuil faible estime de soi (score < 15) :\n")
cat("  N en-dessous du seuil =", sum(donnees$Rosenberg < 15, na.rm = TRUE), "\n")
cat("  % en-dessous du seuil =",
    round(mean(donnees$Rosenberg < 15, na.rm = TRUE) * 100, 1), "%\n\n")

# ============================================================================
# 2. CORRÉLATIONS : FACTEURS ASSOCIÉS À L'ESTIME DE SOI
# ============================================================================

cat("================================================================================\n")
cat("2. FACTEURS ASSOCIÉS À L'ESTIME DE SOI (CORRÉLATIONS)\n")
cat("================================================================================\n\n")

predicteurs        <- c("STAI_Etat", "STAI_Trait", "WHO5",
                        "Toxicite_exposition", "Toxicite_impact",
                        "Sommeil_qualite", "Sommeil_latence", "Sommeil_difficulte",
                        "Fatigue_ressenti", "Niveau_estime", "Niveau_reel", "Age")
labels_predicteurs <- c("Anxiété-État", "Anxiété-Trait", "Bien-être (WHO-5)",
                        "Exposition toxicité", "Impact toxicité",
                        "Qualité sommeil", "Latence sommeil", "Difficultés sommeil",
                        "Fatigue ressentie", "Niveau estimé", "Niveau réel", "Âge")

cat("Corrélations avec Rosenberg :\n")
cat("------------------------------\n")
for(i in seq_along(predicteurs)) {
  cor_res <- cor.test(donnees$Rosenberg, donnees[[predicteurs[i]]])
  cat(labels_predicteurs[i], ": r =", round(cor_res$estimate, 3),
      ", p =", round(cor_res$p.value, 3),
      ifelse(cor_res$p.value < 0.05, " ***", ""), "\n")
}

# Graphiques des corrélations significatives
par(mfrow = c(2, 3))
for(i in seq_along(predicteurs)) {
  cor_res <- cor.test(donnees$Rosenberg, donnees[[predicteurs[i]]])
  if(cor_res$p.value < 0.05) {
    plot(donnees[[predicteurs[i]]], donnees$Rosenberg,
         pch = 19, col = rgb(0.8, 0.4, 0.2, 0.5), cex = 1.5,
         xlab = labels_predicteurs[i],
         ylab = "Rosenberg",
         main = paste0(labels_predicteurs[i], "\nr = ",
                       round(cor_res$estimate, 3),
                       ", p = ", round(cor_res$p.value, 3)))
    abline(lm(donnees$Rosenberg ~ donnees[[predicteurs[i]]]),
           col = "darkorange", lwd = 2)
  }
}
par(mfrow = c(1, 1))

# ============================================================================
# 3. RÉGRESSION MULTIPLE
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("3. RÉGRESSION MULTIPLE : QUELS FACTEURS PRÉDISENT L'ESTIME DE SOI ?\n")
cat("================================================================================\n\n")

modele_rosenberg <- lm(Rosenberg ~ STAI_Etat + STAI_Trait + WHO5 +
                         Toxicite_exposition + Toxicite_impact +
                         Sommeil_qualite + Fatigue_ressenti,
                       data = donnees)

cat("Modèle de régression multiple :\n")
print(summary(modele_rosenberg))

cat("\nVariance expliquée (R²) =",
    round(summary(modele_rosenberg)$r.squared, 3), "\n")
cat("R² ajusté =",
    round(summary(modele_rosenberg)$adj.r.squared, 3), "\n")

# ============================================================================
# 4. ESTIME DE SOI SELON LE GENRE
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("4. ESTIME DE SOI SELON LE GENRE\n")
cat("================================================================================\n\n")

stats_rosen_genre <- donnees_genre %>%
  group_by(Genre_clean) %>%
  summarise(
    n = n(),
    M_Rosenberg  = mean(Rosenberg, na.rm = TRUE),
    ET_Rosenberg = sd(Rosenberg, na.rm = TRUE),
    Min = min(Rosenberg, na.rm = TRUE),
    Max = max(Rosenberg, na.rm = TRUE),
    .groups = "drop"
  )

stats_rosen_genre %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_rosen_genre <- t.test(Rosenberg ~ Genre_clean, data = donnees_genre)
cat("\nTest t : t =", round(test_rosen_genre$statistic, 3),
    ", p =", round(test_rosen_genre$p.value, 3),
    ifelse(test_rosen_genre$p.value < 0.05, " ***", ""), "\n")

boxplot(Rosenberg ~ Genre_clean, data = donnees_genre,
        main = paste0("Estime de soi par genre\np = ",
                      round(test_rosen_genre$p.value, 3)),
        col = c("pink", "lightblue"), ylab = "Rosenberg")

# ============================================================================
# 5. ESTIME DE SOI SELON LE TYPE DE JEU
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("5. ESTIME DE SOI SELON LE TYPE DE JEU\n")
cat("================================================================================\n\n")

donnees_h5 <- donnees[donnees$Type_jeu_cat != "Les deux", ]
donnees_h5$Type_jeu_cat <- factor(donnees_h5$Type_jeu_cat,
                                  levels = c("Non-compétitif", "Compétitif"))

stats_rosen_jeu <- donnees_h5 %>%
  group_by(Type_jeu_cat) %>%
  summarise(
    n = n(),
    M_Rosenberg  = mean(Rosenberg, na.rm = TRUE),
    ET_Rosenberg = sd(Rosenberg, na.rm = TRUE),
    Min = min(Rosenberg, na.rm = TRUE),
    Max = max(Rosenberg, na.rm = TRUE),
    .groups = "drop"
  )

stats_rosen_jeu %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_rosen_jeu <- t.test(Rosenberg ~ Type_jeu_cat, data = donnees_h5)
cat("\nTest t : t =", round(test_rosen_jeu$statistic, 3),
    ", p =", round(test_rosen_jeu$p.value, 3),
    ifelse(test_rosen_jeu$p.value < 0.05, " ***", ""), "\n")

boxplot(Rosenberg ~ Type_jeu_cat, data = donnees_h5,
        main = paste0("Estime de soi par type de jeu\np = ",
                      round(test_rosen_jeu$p.value, 3)),
        col = c("lightgreen", "lightyellow"), ylab = "Rosenberg")

# ============================================================================
# 6. ESTIME DE SOI SELON LA FRÉQUENCE DE JEU
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("6. ESTIME DE SOI SELON LA FRÉQUENCE DE JEU\n")
cat("================================================================================\n\n")

stats_rosen_freq <- donnees %>%
  group_by(Freq_simple) %>%
  summarise(
    n = n(),
    M_Rosenberg  = mean(Rosenberg, na.rm = TRUE),
    ET_Rosenberg = sd(Rosenberg, na.rm = TRUE),
    Min = min(Rosenberg, na.rm = TRUE),
    Max = max(Rosenberg, na.rm = TRUE),
    .groups = "drop"
  )

stats_rosen_freq %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_rosen_freq <- t.test(Rosenberg ~ Freq_simple, data = donnees)
cat("\nTest t : t =", round(test_rosen_freq$statistic, 3),
    ", p =", round(test_rosen_freq$p.value, 3),
    ifelse(test_rosen_freq$p.value < 0.05, " ***", ""), "\n")

boxplot(Rosenberg ~ Freq_simple, data = donnees,
        main = paste0("Estime de soi par fréquence\np = ",
                      round(test_rosen_freq$p.value, 3)),
        col = c("lightgreen", "lightyellow"), ylab = "Rosenberg")

# ============================================================================
# 7. ESTIME DE SOI SELON L'ÂGE
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("7. ESTIME DE SOI SELON L'ÂGE\n")
cat("================================================================================\n\n")

stats_rosen_age <- donnees %>%
  group_by(Age_cat) %>%
  summarise(
    n = n(),
    M_Rosenberg  = mean(Rosenberg, na.rm = TRUE),
    ET_Rosenberg = sd(Rosenberg, na.rm = TRUE),
    .groups = "drop"
  )

stats_rosen_age %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

anova_rosen_age <- aov(Rosenberg ~ Age_cat, data = donnees)
cat("\nANOVA Âge → Estime de soi :\n")
print(summary(anova_rosen_age))

cor_age_rosen <- cor.test(donnees$Age, donnees$Rosenberg)
cat("\nCorrélation Age → Estime de soi : r =", round(cor_age_rosen$estimate, 3),
    ", p =", round(cor_age_rosen$p.value, 3),
    ifelse(cor_age_rosen$p.value < 0.05, " ***", ""), "\n")

boxplot(Rosenberg ~ Age_cat, data = donnees,
        main = "Estime de soi par tranche d'âge",
        col = "lightsalmon", ylab = "Rosenberg")

# ============================================================================
# RÉSUMÉ FINAL ROSENBERG
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("RÉSUMÉ : FACTEURS ASSOCIÉS À L'ESTIME DE SOI (ROSENBERG)\n")
cat("================================================================================\n\n")

cat("DESCRIPTION :\n")
cat("  Moyenne =", round(mean(donnees$Rosenberg, na.rm = TRUE), 2), "\n")
cat("  ET =", round(sd(donnees$Rosenberg, na.rm = TRUE), 2), "\n")
cat("  % faible estime de soi (<15) =",
    round(mean(donnees$Rosenberg < 15, na.rm = TRUE) * 100, 1), "%\n\n")

cat("CORRÉLATIONS SIGNIFICATIVES :\n")
for(i in seq_along(predicteurs)) {
  cor_res <- cor.test(donnees$Rosenberg, donnees[[predicteurs[i]]])
  if(cor_res$p.value < 0.05) {
    cat(" ", labels_predicteurs[i], ": r =", round(cor_res$estimate, 3),
        ", p =", round(cor_res$p.value, 3), " ***\n")
  }
}

cat("\nCOMPARAISONS PAR GROUPES :\n")
cat("  Genre : p =", round(test_rosen_genre$p.value, 3),
    ifelse(test_rosen_genre$p.value < 0.05, " *** Différence",
           " (pas de différence)"), "\n")
cat("  Type de jeu : p =", round(test_rosen_jeu$p.value, 3),
    ifelse(test_rosen_jeu$p.value < 0.05, " *** Différence",
           " (pas de différence)"), "\n")
cat("  Fréquence : p =", round(test_rosen_freq$p.value, 3),
    ifelse(test_rosen_freq$p.value < 0.05, " *** Différence",
           " (pas de différence)"), "\n")
cat("  Âge (corrélation) : r =", round(cor_age_rosen$estimate, 3),
    ", p =", round(cor_age_rosen$p.value, 3),
    ifelse(cor_age_rosen$p.value < 0.05, " ***",
           " (pas de différence)"), "\n\n")

cat("RÉGRESSION MULTIPLE :\n")
cat("  R² =", round(summary(modele_rosenberg)$r.squared, 3), "\n")
cat("  R² ajusté =", round(summary(modele_rosenberg)$adj.r.squared, 3), "\n\n")

cat("*** = p < 0.05 (significatif)\n")
cat("================================================================================\n")