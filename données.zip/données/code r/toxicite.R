# ============================================================================
# ANALYSES APPROFONDIES : EFFETS DE LA TOXICITÉ
# ============================================================================
library(readxl)
library(ggplot2)
library(dplyr)

# ===== CHARGEMENT =====
donnees_raw <- read_excel("tableau fin mémoire.xlsx")
donnees <- donnees_raw

colnames(donnees) <- c("ID", "Age", "Genre", "Type_jeu", "Type_joueur",
                       "Frequence", "Niveau_estime", "Niveau_reel",
                       "Toxicite_exposition", "Toxicite_impact",
                       "STAI_Etat", "STAI_Trait", "WHO5", "Rosenberg",
                       "Sommeil_latence", "Sommeil_difficulte",
                       "Sommeil_qualite", "Fatigue_ressenti")

# Conversion colonnes texte → scores numériques
donnees$Sommeil_latence <- case_when(
  grepl("15min|15 min|égale à 15", donnees_raw[[15]])  ~ 1,
  grepl("16 à 30|16à30", donnees_raw[[15]])            ~ 2,
  grepl("31 à 60|31à60", donnees_raw[[15]])            ~ 3,
  grepl("Supérieur à 60|60min", donnees_raw[[15]])     ~ 4,
  TRUE ~ NA_real_
)

donnees$Sommeil_difficulte <- case_when(
  grepl("Pas au cours", donnees_raw[[16]])             ~ 0,
  grepl("Inférieur à 1", donnees_raw[[16]])            ~ 1,
  grepl("2 à 3 fois", donnees_raw[[16]])               ~ 2,
  grepl("3 à 4 fois", donnees_raw[[16]])               ~ 3,
  TRUE ~ NA_real_
)

# Conversion numérique
colonnes_num <- c("STAI_Etat", "STAI_Trait", "WHO5", "Rosenberg",
                  "Toxicite_exposition", "Toxicite_impact",
                  "Niveau_estime", "Niveau_reel",
                  "Sommeil_qualite", "Fatigue_ressenti")

for(col in colonnes_num) {
  donnees[[col]] <- as.numeric(donnees[[col]])
}

# Variables dérivées
donnees$Genre_clean <- factor(
  ifelse(grepl("Homme|homme", donnees$Genre), "Homme",
         ifelse(grepl("Femme|femme", donnees$Genre), "Femme", NA)),
  levels = c("Femme", "Homme")
)

donnees$Type_jeu_cat <- ifelse(
  grepl("Compétitif", donnees$Type_jeu) & !grepl("Non", donnees$Type_jeu),
  "Compétitif",
  ifelse(grepl("Non", donnees$Type_jeu), "Non-compétitif", "Les deux")
)

donnees$Freq_simple <- ifelse(grepl("tous les jours", donnees$Frequence),
                              "Quotidien", "Non-quotidien")

# Groupes de toxicité (terciles)
donnees$Tox_groupe_exp <- cut(donnees$Toxicite_exposition,
                              breaks = quantile(donnees$Toxicite_exposition, 
                                                probs = c(0, 0.33, 0.66, 1), na.rm = TRUE),
                              labels = c("Faible", "Moyen", "Élevé"),
                              include.lowest = TRUE)

donnees$Tox_groupe_imp <- cut(donnees$Toxicite_impact,
                              breaks = quantile(donnees$Toxicite_impact,
                                                probs = c(0, 0.33, 0.66, 1), na.rm = TRUE),
                              labels = c("Faible", "Moyen", "Élevé"),
                              include.lowest = TRUE)

# Sous-groupes
donnees_genre <- donnees[!is.na(donnees$Genre_clean), ]
hommes <- donnees_genre[donnees_genre$Genre_clean == "Homme", ]
femmes <- donnees_genre[donnees_genre$Genre_clean == "Femme", ]

cat("================================================================================\n")
cat("ANALYSES APPROFONDIES SUR LA TOXICITÉ\n")
cat("================================================================================\n")
cat("N total =", nrow(donnees), "participants\n")
cat("Exposition moyenne =", round(mean(donnees$Toxicite_exposition, na.rm=TRUE), 2), "\n")
cat("Impact moyen =", round(mean(donnees$Toxicite_impact, na.rm=TRUE), 2), "\n\n")

# ============================================================================
# 1. STATISTIQUES DESCRIPTIVES DE LA TOXICITÉ
# ============================================================================

cat("================================================================================\n")
cat("1. DESCRIPTION DE L'EXPOSITION ET DE L'IMPACT\n")
cat("================================================================================\n\n")

stats_tox <- donnees %>%
  summarise(
    N = n(),
    M_exposition  = mean(Toxicite_exposition, na.rm = TRUE),
    ET_exposition = sd(Toxicite_exposition, na.rm = TRUE),
    Min_exp       = min(Toxicite_exposition, na.rm = TRUE),
    Max_exp       = max(Toxicite_exposition, na.rm = TRUE),
    M_impact      = mean(Toxicite_impact, na.rm = TRUE),
    ET_impact     = sd(Toxicite_impact, na.rm = TRUE),
    Min_imp       = min(Toxicite_impact, na.rm = TRUE),
    Max_imp       = max(Toxicite_impact, na.rm = TRUE)
  )

stats_tox %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

cat("\nRépartition par niveau d'exposition :\n")
print(table(donnees$Tox_groupe_exp))
cat("\nRépartition par niveau d'impact :\n")
print(table(donnees$Tox_groupe_imp))

# Graphiques descriptifs
par(mfrow = c(1, 2))
hist(donnees$Toxicite_exposition,
     main = "Distribution de l'exposition\nà la toxicité",
     xlab = "Score d'exposition (1-5)",
     col = "lightyellow", border = "orange")
hist(donnees$Toxicite_impact,
     main = "Distribution de l'impact\némotionnel",
     xlab = "Score d'impact (1-5)",
     col = "lightyellow", border = "red")
par(mfrow = c(1, 1))

# ============================================================================
# 2. TOXICITÉ → SANTÉ MENTALE (CORRÉLATIONS)
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("2. TOXICITÉ → SANTÉ MENTALE (CORRÉLATIONS)\n")
cat("================================================================================\n\n")

variables_sante <- c("STAI_Etat", "STAI_Trait", "WHO5", "Rosenberg")
labels_sante    <- c("Anxiété-État", "Anxiété-Trait", "Bien-être (WHO-5)", "Estime de soi")

cat("EXPOSITION À LA TOXICITÉ :\n")
cat("---------------------------\n")
for(i in seq_along(variables_sante)) {
  cor_res <- cor.test(donnees$Toxicite_exposition, donnees[[variables_sante[i]]])
  cat(labels_sante[i], ": r =", round(cor_res$estimate, 3),
      ", p =", round(cor_res$p.value, 3),
      ifelse(cor_res$p.value < 0.05, " ***", ""), "\n")
}

cat("\nIMPACT ÉMOTIONNEL DE LA TOXICITÉ :\n")
cat("------------------------------------\n")
for(i in seq_along(variables_sante)) {
  cor_res <- cor.test(donnees$Toxicite_impact, donnees[[variables_sante[i]]])
  cat(labels_sante[i], ": r =", round(cor_res$estimate, 3),
      ", p =", round(cor_res$p.value, 3),
      ifelse(cor_res$p.value < 0.05, " ***", ""), "\n")
}

# Graphiques corrélations
par(mfrow = c(2, 2))
for(i in seq_along(variables_sante)) {
  plot(donnees$Toxicite_impact, donnees[[variables_sante[i]]],
       pch = 19, col = rgb(0.8, 0.2, 0.2, 0.5), cex = 1.5,
       xlab = "Impact émotionnel toxicité",
       ylab = labels_sante[i],
       main = paste0("Toxicité → ", labels_sante[i]))
  abline(lm(donnees[[variables_sante[i]]] ~ donnees$Toxicite_impact), 
         col = "red", lwd = 2)
}
par(mfrow = c(1, 1))

# ============================================================================
# 3. TOXICITÉ → SOMMEIL
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("3. TOXICITÉ → QUALITÉ DU SOMMEIL\n")
cat("================================================================================\n\n")

variables_sommeil <- c("Sommeil_qualite", "Sommeil_latence", "Sommeil_difficulte")
labels_sommeil    <- c("Qualité globale", "Latence d'endormissement", "Difficultés d'endormissement")

cat("EXPOSITION → SOMMEIL :\n")
cat("----------------------\n")
for(i in seq_along(variables_sommeil)) {
  cor_res <- cor.test(donnees$Toxicite_exposition, donnees[[variables_sommeil[i]]])
  cat(labels_sommeil[i], ": r =", round(cor_res$estimate, 3),
      ", p =", round(cor_res$p.value, 3),
      ifelse(cor_res$p.value < 0.05, " ***", ""), "\n")
}

cat("\nIMPACT → SOMMEIL :\n")
cat("-------------------\n")
for(i in seq_along(variables_sommeil)) {
  cor_res <- cor.test(donnees$Toxicite_impact, donnees[[variables_sommeil[i]]])
  cat(labels_sommeil[i], ": r =", round(cor_res$estimate, 3),
      ", p =", round(cor_res$p.value, 3),
      ifelse(cor_res$p.value < 0.05, " ***", ""), "\n")
}

# ============================================================================
# 4. TOXICITÉ × TYPE DE JEU
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("4. TOXICITÉ SELON LE TYPE DE JEU\n")
cat("================================================================================\n\n")

cat("Question : Les joueurs compétitifs sont-ils plus exposés à la toxicité ?\n\n")

donnees_h4 <- donnees[donnees$Type_jeu_cat != "Les deux", ]

stats_tox_jeu <- donnees_h4 %>%
  group_by(Type_jeu_cat) %>%
  summarise(
    n = n(),
    M_exposition  = mean(Toxicite_exposition, na.rm = TRUE),
    ET_exposition = sd(Toxicite_exposition, na.rm = TRUE),
    M_impact      = mean(Toxicite_impact, na.rm = TRUE),
    ET_impact     = sd(Toxicite_impact, na.rm = TRUE),
    .groups = "drop"
  )

cat("Toxicité par type de jeu :\n")
stats_tox_jeu %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_tox_jeu_exp <- t.test(Toxicite_exposition ~ Type_jeu_cat, data = donnees_h4)
test_tox_jeu_imp <- t.test(Toxicite_impact ~ Type_jeu_cat, data = donnees_h4)

cat("\nTests t :\n")
cat("  Exposition : t =", round(test_tox_jeu_exp$statistic, 3),
    ", p =", round(test_tox_jeu_exp$p.value, 3),
    ifelse(test_tox_jeu_exp$p.value < 0.05, " ***", ""), "\n")
cat("  Impact : t =", round(test_tox_jeu_imp$statistic, 3),
    ", p =", round(test_tox_jeu_imp$p.value, 3),
    ifelse(test_tox_jeu_imp$p.value < 0.05, " ***", ""), "\n")

par(mfrow = c(1, 2))
boxplot(Toxicite_exposition ~ Type_jeu_cat, data = donnees_h4,
        main = paste0("Exposition toxicité\npar type de jeu\np = ",
                      round(test_tox_jeu_exp$p.value, 3)),
        col = c("lightgreen", "lightyellow"),
        ylab = "Score d'exposition")
boxplot(Toxicite_impact ~ Type_jeu_cat, data = donnees_h4,
        main = paste0("Impact émotionnel\npar type de jeu\np = ",
                      round(test_tox_jeu_imp$p.value, 3)),
        col = c("lightgreen", "lightyellow"),
        ylab = "Score d'impact")
par(mfrow = c(1, 1))

# ============================================================================
# 5. TOXICITÉ × GENRE
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("5. TOXICITÉ SELON LE GENRE\n")
cat("================================================================================\n\n")

stats_tox_genre <- donnees_genre %>%
  group_by(Genre_clean) %>%
  summarise(
    n = n(),
    M_exposition  = mean(Toxicite_exposition, na.rm = TRUE),
    ET_exposition = sd(Toxicite_exposition, na.rm = TRUE),
    M_impact      = mean(Toxicite_impact, na.rm = TRUE),
    ET_impact     = sd(Toxicite_impact, na.rm = TRUE),
    .groups = "drop"
  )

cat("Toxicité par genre :\n")
stats_tox_genre %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_tox_genre_exp <- t.test(Toxicite_exposition ~ Genre_clean, data = donnees_genre)
test_tox_genre_imp <- t.test(Toxicite_impact ~ Genre_clean, data = donnees_genre)

cat("\nTests t :\n")
cat("  Exposition : t =", round(test_tox_genre_exp$statistic, 3),
    ", p =", round(test_tox_genre_exp$p.value, 3),
    ifelse(test_tox_genre_exp$p.value < 0.05, " ***", ""), "\n")
cat("  Impact : t =", round(test_tox_genre_imp$statistic, 3),
    ", p =", round(test_tox_genre_imp$p.value, 3),
    ifelse(test_tox_genre_imp$p.value < 0.05, " ***", ""), "\n")

par(mfrow = c(1, 2))
boxplot(Toxicite_exposition ~ Genre_clean, data = donnees_genre,
        main = paste0("Exposition toxicité\npar genre\np = ",
                      round(test_tox_genre_exp$p.value, 3)),
        col = c("pink", "lightblue"),
        ylab = "Score d'exposition")
boxplot(Toxicite_impact ~ Genre_clean, data = donnees_genre,
        main = paste0("Impact émotionnel\npar genre\np = ",
                      round(test_tox_genre_imp$p.value, 3)),
        col = c("pink", "lightblue"),
        ylab = "Score d'impact")
par(mfrow = c(1, 1))

# ============================================================================
# 6. TOXICITÉ × FRÉQUENCE DE JEU
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("6. TOXICITÉ SELON LA FRÉQUENCE DE JEU\n")
cat("================================================================================\n\n")

cat("Question : Les joueurs quotidiens sont-ils plus exposés à la toxicité ?\n\n")

stats_tox_freq <- donnees %>%
  group_by(Freq_simple) %>%
  summarise(
    n = n(),
    M_exposition  = mean(Toxicite_exposition, na.rm = TRUE),
    ET_exposition = sd(Toxicite_exposition, na.rm = TRUE),
    M_impact      = mean(Toxicite_impact, na.rm = TRUE),
    ET_impact     = sd(Toxicite_impact, na.rm = TRUE),
    .groups = "drop"
  )

cat("Toxicité par fréquence de jeu :\n")
stats_tox_freq %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

test_tox_freq_exp <- t.test(Toxicite_exposition ~ Freq_simple, data = donnees)
test_tox_freq_imp <- t.test(Toxicite_impact ~ Freq_simple, data = donnees)

cat("\nTests t :\n")
cat("  Exposition : t =", round(test_tox_freq_exp$statistic, 3),
    ", p =", round(test_tox_freq_exp$p.value, 3),
    ifelse(test_tox_freq_exp$p.value < 0.05, " ***", ""), "\n")
cat("  Impact : t =", round(test_tox_freq_imp$statistic, 3),
    ", p =", round(test_tox_freq_imp$p.value, 3),
    ifelse(test_tox_freq_imp$p.value < 0.05, " ***", ""), "\n")

# ============================================================================
# RÉSUMÉ FINAL TOXICITÉ
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("RÉSUMÉ : EFFETS DE LA TOXICITÉ\n")
cat("================================================================================\n\n")

cat("TOXICITÉ → SANTÉ MENTALE :\n")
cor_exp_anxiete <- cor.test(donnees$Toxicite_exposition, donnees$STAI_Etat)
cor_imp_anxiete <- cor.test(donnees$Toxicite_impact, donnees$STAI_Etat)
cor_imp_who5    <- cor.test(donnees$Toxicite_impact, donnees$WHO5)
cor_imp_rosen   <- cor.test(donnees$Toxicite_impact, donnees$Rosenberg)

cat("  Exposition → Anxiété-État : r =", round(cor_exp_anxiete$estimate, 3),
    ", p =", round(cor_exp_anxiete$p.value, 3),
    ifelse(cor_exp_anxiete$p.value < 0.05, " ***", " (non sig.)"), "\n")
cat("  Impact → Anxiété-État : r =", round(cor_imp_anxiete$estimate, 3),
    ", p =", round(cor_imp_anxiete$p.value, 3),
    ifelse(cor_imp_anxiete$p.value < 0.05, " ***", " (non sig.)"), "\n")
cat("  Impact → Bien-être : r =", round(cor_imp_who5$estimate, 3),
    ", p =", round(cor_imp_who5$p.value, 3),
    ifelse(cor_imp_who5$p.value < 0.05, " ***", " (non sig.)"), "\n")
cat("  Impact → Estime de soi : r =", round(cor_imp_rosen$estimate, 3),
    ", p =", round(cor_imp_rosen$p.value, 3),
    ifelse(cor_imp_rosen$p.value < 0.05, " ***", " (non sig.)"), "\n\n")

cat("TOXICITÉ SELON LE TYPE DE JEU :\n")
cat("  Exposition : p =", round(test_tox_jeu_exp$p.value, 3),
    ifelse(test_tox_jeu_exp$p.value < 0.05, " *** Compétitif plus exposé", 
           " (pas de différence)"), "\n")
cat("  Impact : p =", round(test_tox_jeu_imp$p.value, 3),
    ifelse(test_tox_jeu_imp$p.value < 0.05, " *** Différence", 
           " (pas de différence)"), "\n\n")

cat("TOXICITÉ SELON LE GENRE :\n")
cat("  Exposition : p =", round(test_tox_genre_exp$p.value, 3),
    ifelse(test_tox_genre_exp$p.value < 0.05, " *** Différence", 
           " (pas de différence)"), "\n")
cat("  Impact : p =", round(test_tox_genre_imp$p.value, 3),
    ifelse(test_tox_genre_imp$p.value < 0.05, " *** Différence", 
           " (pas de différence)"), "\n\n")

cat("TOXICITÉ SELON LA FRÉQUENCE :\n")
cat("  Exposition : p =", round(test_tox_freq_exp$p.value, 3),
    ifelse(test_tox_freq_exp$p.value < 0.05, " *** Quotidien plus exposé", 
           " (pas de différence)"), "\n")
cat("  Impact : p =", round(test_tox_freq_imp$p.value, 3),
    ifelse(test_tox_freq_imp$p.value < 0.05, " *** Différence", 
           " (pas de différence)"), "\n\n")

cat("*** = p < 0.05 (significatif)\n")
cat("================================================================================\n")