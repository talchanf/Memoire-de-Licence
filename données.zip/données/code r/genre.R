# ============================================================================
# ANALYSES APPROFONDIES : EFFETS DU GENRE
# ============================================================================
#install.packages(c("readxl", "ggplot2", "dplyr"))
library(readxl)
library(ggplot2)
library(dplyr)

# ===== CHARGEMENT =====
donnees_raw <- read_excel("tableau fin mémoire.xlsx")
donnees <- donnees_raw

colnames(donnees) <- c("ID", "Age", "Genre", "Type_jeu", "Type_joueur",
                       "Frequence", "Niveau_estime", "Niveau_reel",
                       "Toxicite_exposition", "Toxicite_impact",
                       "STAI_Etat", "STAI_Trait", "WHO5", "Rosenberg",
                       "Sommeil_latence", "Sommeil_difficulte",
                       "Sommeil_qualite", "Fatigue_ressenti")

# Conversion colonnes texte → scores numériques
donnees$Sommeil_latence <- case_when(
  grepl("15min|15 min|égale à 15", donnees_raw[[15]])  ~ 1,
  grepl("16 à 30|16à30", donnees_raw[[15]])            ~ 2,
  grepl("31 à 60|31à60", donnees_raw[[15]])            ~ 3,
  grepl("Supérieur à 60|60min", donnees_raw[[15]])     ~ 4,
  TRUE ~ NA_real_
)

donnees$Sommeil_difficulte <- case_when(
  grepl("Pas au cours", donnees_raw[[16]])             ~ 0,
  grepl("Inférieur à 1", donnees_raw[[16]])            ~ 1,
  grepl("2 à 3 fois", donnees_raw[[16]])               ~ 2,
  grepl("3 à 4 fois", donnees_raw[[16]])               ~ 3,
  TRUE ~ NA_real_
)

# Conversion numérique des autres colonnes
colonnes_num <- c("STAI_Etat", "STAI_Trait", "WHO5", "Rosenberg",
                  "Toxicite_exposition", "Toxicite_impact",
                  "Niveau_estime", "Niveau_reel",
                  "Sommeil_qualite", "Fatigue_ressenti")

for(col in colonnes_num) {
  donnees[[col]] <- as.numeric(donnees[[col]])
}

# Variables dérivées
donnees$Genre_clean <- factor(
  ifelse(grepl("Homme|homme", donnees$Genre), "Homme",
         ifelse(grepl("Femme|femme", donnees$Genre), "Femme", NA)),
  levels = c("Femme", "Homme")
)

donnees$Type_jeu_cat <- ifelse(
  grepl("Compétitif", donnees$Type_jeu) & !grepl("Non", donnees$Type_jeu),
  "Compétitif",
  ifelse(grepl("Non", donnees$Type_jeu), "Non-compétitif", "Les deux")
)

donnees$Freq_simple <- ifelse(grepl("tous les jours", donnees$Frequence),
                              "Quotidien", "Non-quotidien")

# Filtrer et créer sous-groupes
donnees_genre <- donnees[!is.na(donnees$Genre_clean), ]
hommes <- donnees_genre[donnees_genre$Genre_clean == "Homme", ]
femmes <- donnees_genre[donnees_genre$Genre_clean == "Femme", ]

# Vérification
cat("Tables sommeil :\n")
print(table(donnees_genre$Sommeil_latence))
print(table(donnees_genre$Sommeil_difficulte))

cat("================================================================================\n")
cat("ANALYSES APPROFONDIES SUR LE GENRE\n")
cat("================================================================================\n")
cat("N total =", nrow(donnees_genre), "participants\n")
cat("Hommes =", sum(donnees_genre$Genre_clean == "Homme"), "\n")
cat("Femmes =", sum(donnees_genre$Genre_clean == "Femme"), "\n\n")

# ============================================================================
# 1. DIFFÉRENCES DE BASE PAR GENRE
# ============================================================================

cat("================================================================================\n")
cat("1. DIFFÉRENCES DE SANTÉ MENTALE PAR GENRE (EFFET PRINCIPAL)\n")
cat("================================================================================\n\n")

# Statistiques descriptives par genre
donnees_genre <- donnees_genre %>%
  mutate(
    STAI_Etat  = as.numeric(STAI_Etat),
    STAI_Trait = as.numeric(STAI_Trait),
    WHO5       = as.numeric(WHO5),
    Rosenberg  = as.numeric(Rosenberg)
  )

stats_genre_base <- donnees_genre %>%
  group_by(Genre_clean) %>%
  summarise(
    N = n(),
    M_STAI_Etat = mean(STAI_Etat, na.rm = TRUE),
    ET_STAI_Etat = sd(STAI_Etat, na.rm = TRUE),
    M_STAI_Trait = mean(STAI_Trait, na.rm = TRUE),
    ET_STAI_Trait = sd(STAI_Trait, na.rm = TRUE),
    M_WHO5 = mean(WHO5, na.rm = TRUE),
    ET_WHO5 = sd(WHO5, na.rm = TRUE),
    M_Rosenberg = mean(Rosenberg, na.rm = TRUE),
    ET_Rosenberg = sd(Rosenberg, na.rm = TRUE),
    .groups = "drop"
  )
print(stats_genre_base)

# Tests t pour chaque variable
cat("\nTests t (Homme vs Femme) :\n")
cat("---------------------------\n")

test_anxiete_etat <- t.test(STAI_Etat ~ Genre_clean, data = donnees_genre)
test_anxiete_trait <- t.test(STAI_Trait ~ Genre_clean, data = donnees_genre)
test_who5 <- t.test(WHO5 ~ Genre_clean, data = donnees_genre)
test_rosenberg <- t.test(Rosenberg ~ Genre_clean, data = donnees_genre)

cat("Anxiété-État : t =", round(test_anxiete_etat$statistic, 3), 
    ", p =", round(test_anxiete_etat$p.value, 3),
    ifelse(test_anxiete_etat$p.value < 0.05, " ***", ""), "\n")
cat("Anxiété-Trait : t =", round(test_anxiete_trait$statistic, 3), 
    ", p =", round(test_anxiete_trait$p.value, 3),
    ifelse(test_anxiete_trait$p.value < 0.05, " ***", ""), "\n")
cat("Bien-être : t =", round(test_who5$statistic, 3), 
    ", p =", round(test_who5$p.value, 3),
    ifelse(test_who5$p.value < 0.05, " ***", ""), "\n")
cat("Estime de soi : t =", round(test_rosenberg$statistic, 3), 
    ", p =", round(test_rosenberg$p.value, 3),
    ifelse(test_rosenberg$p.value < 0.05, " ***", ""), "\n")

# Graphique comparatif
par(mfrow = c(2, 2))

boxplot(STAI_Etat ~ Genre_clean, data = donnees_genre,
        main = paste0("Anxiété-État par genre\np = ", 
                      round(test_anxiete_etat$p.value, 3)),
        col = c("pink", "lightblue"), ylab = "STAI-État")

boxplot(STAI_Trait ~ Genre_clean, data = donnees_genre,
        main = paste0("Anxiété-Trait par genre\np = ", 
                      round(test_anxiete_trait$p.value, 3)),
        col = c("pink", "lightblue"), ylab = "STAI-Trait")

boxplot(WHO5 ~ Genre_clean, data = donnees_genre,
        main = paste0("Bien-être par genre\np = ", 
                      round(test_who5$p.value, 3)),
        col = c("pink", "lightblue"), ylab = "WHO-5")

boxplot(Rosenberg ~ Genre_clean, data = donnees_genre,
        main = paste0("Estime de soi par genre\np = ", 
                      round(test_rosenberg$p.value, 3)),
        col = c("pink", "lightblue"), ylab = "Rosenberg")

par(mfrow = c(1, 1))

# ============================================================================
# 2. GENRE × TYPE DE JEU
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("2. GENRE × TYPE DE JEU → ANXIÉTÉ\n")
cat("================================================================================\n\n")

cat("Question : Les femmes jouant à des jeux compétitifs sont-elles plus anxieuses ?\n\n")

# Filtrer
donnees_g2 <- donnees_genre[donnees_genre$Type_jeu_cat != "Les deux", ]

# Répartition
cat("Répartition Genre × Type de jeu :\n")
print(table(donnees_g2$Genre_clean, donnees_g2$Type_jeu_cat))

# Moyennes par groupe
moyennes_g2 <- donnees_g2 %>%
  group_by(Genre_clean, Type_jeu_cat) %>%
  summarise(
    n = n(),
    M_anxiete = mean(STAI_Etat, na.rm = TRUE),
    ET_anxiete = sd(STAI_Etat, na.rm = TRUE),
    .groups = 'drop'
  )

cat("\nMoyennes Anxiété-État :\n")
moyennes_g2 %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

# ANOVA 2×2
anova_g2 <- aov(STAI_Etat ~ Genre_clean * Type_jeu_cat, data = donnees_g2)
cat("\nANOVA Genre × Type de jeu :\n")
print(summary(anova_g2))

# Graphique d'interaction
ggplot(moyennes_g2, aes(x = Type_jeu_cat, y = M_anxiete, 
                        color = Genre_clean, group = Genre_clean)) +
  geom_line(linewidth = 2) +
  geom_point(size = 5) +
  labs(title = "Interaction Genre × Type de jeu → Anxiété",
       subtitle = "Les femmes sont-elles plus affectées par le compétitif ?",
       x = "Type de jeu", y = "Anxiété-État moyenne", 
       color = "Genre") +
  theme_minimal() +
  scale_color_manual(values = c("Homme" = "steelblue", "Femme" = "hotpink"))

# ============================================================================
# 3. GENRE × TOXICITÉ → ANXIÉTÉ
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("3. GENRE × TOXICITÉ → ANXIÉTÉ\n")
cat("================================================================================\n\n")

cat("Question : Les femmes sont-elles plus vulnérables à la toxicité ?\n\n")

# Exposition à la toxicité par genre
cat("Exposition à la toxicité par genre :\n")
stats_tox_genre <- donnees_genre %>%
  group_by(Genre_clean) %>%
  summarise(
    n = n(),
    M_exposition = mean(Toxicite_exposition, na.rm = TRUE),
    ET_exposition = sd(Toxicite_exposition, na.rm = TRUE),
    M_impact = mean(Toxicite_impact, na.rm = TRUE),
    ET_impact = sd(Toxicite_impact, na.rm = TRUE)
  )
stats_tox_genre %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

# Test différence exposition
# ÉTAPE 1 — Convertir en factor AVANT les tests
donnees_genre$Genre_clean <- factor(donnees_genre$Genre_clean, levels = c("Femme", "Homme"))

# ÉTAPE 2 — Ensuite seulement les t.test
test_tox_exp <- t.test(Toxicite_exposition ~ Genre_clean, data = donnees_genre)
test_tox_imp <- t.test(Toxicite_impact ~ Genre_clean, data = donnees_genre)

cat("\nLes femmes sont-elles PLUS EXPOSÉES à la toxicité ?\n")
cat("  Exposition : t =", round(test_tox_exp$statistic, 3), 
    ", p =", round(test_tox_exp$p.value, 3),
    ifelse(test_tox_exp$p.value < 0.05, " ***", ""), "\n")
cat("  Impact émotionnel : t =", round(test_tox_imp$statistic, 3), 
    ", p =", round(test_tox_imp$p.value, 3),
    ifelse(test_tox_imp$p.value < 0.05, " ***", ""), "\n\n")

# Corrélations Toxicité → Anxiété par genre
hommes <- donnees_genre[donnees_genre$Genre_clean == "Homme", ]
femmes <- donnees_genre[donnees_genre$Genre_clean == "Femme", ]

cor_h_exp <- cor.test(hommes$Toxicite_exposition, hommes$STAI_Etat)
cor_f_exp <- cor.test(femmes$Toxicite_exposition, femmes$STAI_Etat)

cor_h_imp <- cor.test(hommes$Toxicite_impact, hommes$STAI_Etat)
cor_f_imp <- cor.test(femmes$Toxicite_impact, femmes$STAI_Etat)

cat("Corrélations Toxicité → Anxiété par genre :\n")
cat("\nEXPOSITION :\n")
cat("  Hommes : r =", round(cor_h_exp$estimate, 3), 
    ", p =", round(cor_h_exp$p.value, 3),
    ifelse(cor_h_exp$p.value < 0.05, " ***", ""), "\n")
cat("  Femmes : r =", round(cor_f_exp$estimate, 3), 
    ", p =", round(cor_f_exp$p.value, 3),
    ifelse(cor_f_exp$p.value < 0.05, " ***", ""), "\n")

cat("\nIMPACT ÉMOTIONNEL :\n")
cat("  Hommes : r =", round(cor_h_imp$estimate, 3), 
    ", p =", round(cor_h_imp$p.value, 3),
    ifelse(cor_h_imp$p.value < 0.05, " ***", ""), "\n")
cat("  Femmes : r =", round(cor_f_imp$estimate, 3), 
    ", p =", round(cor_f_imp$p.value, 3),
    ifelse(cor_f_imp$p.value < 0.05, " ***", ""), "\n")

# Graphique double
par(mfrow = c(1, 2))

# Exposition
plot(hommes$Toxicite_exposition, hommes$STAI_Etat,
     col = rgb(0, 0, 1, 0.5), pch = 19, cex = 2,
     xlim = range(donnees_genre$Toxicite_exposition, na.rm = TRUE),
     ylim = range(donnees_genre$STAI_Etat, na.rm = TRUE),
     xlab = "Exposition toxicité", ylab = "Anxiété-État",
     main = "Toxicité → Anxiété par genre")
points(femmes$Toxicite_exposition, femmes$STAI_Etat,
       col = rgb(1, 0, 0.5, 0.5), pch = 19, cex = 2)
abline(lm(STAI_Etat ~ Toxicite_exposition, data = hommes), col = "blue", lwd = 2)
abline(lm(STAI_Etat ~ Toxicite_exposition, data = femmes), col = "hotpink", lwd = 2)
legend("topright", legend = c(paste0("Hommes (r=", round(cor_h_exp$estimate, 2), ")"),
                              paste0("Femmes (r=", round(cor_f_exp$estimate, 2), ")")),
       col = c("blue", "hotpink"), lwd = 2)

# Impact
plot(hommes$Toxicite_impact, hommes$STAI_Etat,
     col = rgb(0, 0, 1, 0.5), pch = 19, cex = 2,
     xlim = range(donnees_genre$Toxicite_impact, na.rm = TRUE),
     ylim = range(donnees_genre$STAI_Etat, na.rm = TRUE),
     xlab = "Impact émotionnel", ylab = "Anxiété-État",
     main = "Impact toxicité → Anxiété par genre")
points(femmes$Toxicite_impact, femmes$STAI_Etat,
       col = rgb(1, 0, 0.5, 0.5), pch = 19, cex = 2)
abline(lm(STAI_Etat ~ Toxicite_impact, data = hommes), col = "blue", lwd = 2)
abline(lm(STAI_Etat ~ Toxicite_impact, data = femmes), col = "hotpink", lwd = 2)
legend("topright", legend = c(paste0("Hommes (r=", round(cor_h_imp$estimate, 2), ")"),
                              paste0("Femmes (r=", round(cor_f_imp$estimate, 2), ")")),
       col = c("blue", "hotpink"), lwd = 2)

par(mfrow = c(1, 1))

# ============================================================================
# 4. GENRE × SOMMEIL
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("4. GENRE × QUALITÉ DU SOMMEIL\n")
cat("================================================================================\n\n")

# Stats sommeil par genre
stats_sommeil_genre <- donnees_genre %>%
  group_by(Genre_clean) %>%
  summarise(
    n = n(),
    M_qualite = mean(Sommeil_qualite, na.rm = TRUE),
    ET_qualite = sd(Sommeil_qualite, na.rm = TRUE),
    M_latence = mean(Sommeil_latence, na.rm = TRUE),
    M_difficulte = mean(Sommeil_difficulte, na.rm = TRUE)
  )

cat("Qualité du sommeil par genre :\n")
stats_sommeil_genre %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

# Test t
test_sommeil_genre <- t.test(Sommeil_qualite ~ Genre_clean, data = donnees_genre)
cat("\nTest t qualité sommeil : t =", round(test_sommeil_genre$statistic, 3), 
    ", p =", round(test_sommeil_genre$p.value, 3),
    ifelse(test_sommeil_genre$p.value < 0.05, " ***", ""), "\n")

# Corrélation Sommeil → Anxiété par genre
cor_h_sommeil <- cor.test(hommes$Sommeil_qualite, hommes$STAI_Etat)
cor_f_sommeil <- cor.test(femmes$Sommeil_qualite, femmes$STAI_Etat)

cat("\nCorrélations Sommeil → Anxiété par genre :\n")
cat("  Hommes : r =", round(cor_h_sommeil$estimate, 3), 
    ", p =", round(cor_h_sommeil$p.value, 3),
    ifelse(cor_h_sommeil$p.value < 0.05, " ***", ""), "\n")
cat("  Femmes : r =", round(cor_f_sommeil$estimate, 3), 
    ", p =", round(cor_f_sommeil$p.value, 3),
    ifelse(cor_f_sommeil$p.value < 0.05, " ***", ""), "\n")

# Graphique
boxplot(Sommeil_qualite ~ Genre_clean, data = donnees_genre,
        main = "Qualité du sommeil par genre",
        col = c("pink", "lightblue"),
        ylab = "Qualité du sommeil (1-5)")

# ============================================================================
# 5. GENRE × NIVEAU PERÇU/RÉEL
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("5. GENRE × PERCEPTION DU NIVEAU\n")
cat("================================================================================\n\n")

cat("Question : Les hommes se surestiment-ils plus que les femmes ?\n\n")

# Écart niveau par genre
donnees_genre$Ecart_niveau <- donnees_genre$Niveau_reel - donnees_genre$Niveau_estime

stats_ecart_genre <- donnees_genre %>%
  group_by(Genre_clean) %>%
  summarise(
    n = n(),
    M_ecart = mean(Ecart_niveau, na.rm = TRUE),
    ET_ecart = sd(Ecart_niveau, na.rm = TRUE),
    M_estime = mean(Niveau_estime, na.rm = TRUE),
    M_reel = mean(Niveau_reel, na.rm = TRUE)
  )

cat("Écart niveau (réel - estimé) par genre :\n")
stats_ecart_genre %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  print()

# Test t
test_ecart_genre <- t.test(Ecart_niveau ~ Genre_clean, data = donnees_genre)
cat("\nTest t : t =", round(test_ecart_genre$statistic, 3), 
    ", p =", round(test_ecart_genre$p.value, 3),
    ifelse(test_ecart_genre$p.value < 0.05, " ***", ""), "\n")

cat("\nInterprétation :\n")
cat("  Écart > 0 = Surestimation (pense être meilleur qu'il n'est)\n")
cat("  Écart < 0 = Sous-estimation (pense être moins bon qu'il n'est)\n")

# ============================================================================
# 6. GENRE × FRÉQUENCE DE JEU
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("6. GENRE × FRÉQUENCE DE JEU\n")
cat("================================================================================\n\n")

# Répartition
cat("Répartition Genre × Fréquence :\n")
print(table(donnees_genre$Genre_clean, donnees_genre$Freq_simple))

# Proportions
prop_freq <- donnees_genre %>%
  group_by(Genre_clean, Freq_simple) %>%
  summarise(n = n(), .groups = 'drop') %>%
  group_by(Genre_clean) %>%
  mutate(pct = round(n / sum(n) * 100, 1))

print(prop_freq)

# ============================================================================
# RÉSUMÉ FINAL GENRE
# ============================================================================

cat("\n\n")
cat("================================================================================\n")
cat("RÉSUMÉ : DIFFÉRENCES LIÉES AU GENRE\n")
cat("================================================================================\n\n")

cat("SANTÉ MENTALE DE BASE :\n")
cat("  Anxiété-État : p =", round(test_anxiete_etat$p.value, 3),
    ifelse(test_anxiete_etat$p.value < 0.05, " *** Femmes plus anxieuses", 
           " (pas de différence)"), "\n")
cat("  Bien-être : p =", round(test_who5$p.value, 3),
    ifelse(test_who5$p.value < 0.05, " ***", " (pas de différence)"), "\n\n")

cat("EXPOSITION ET VULNÉRABILITÉ À LA TOXICITÉ :\n")
cat("  Exposition : p =", round(test_tox_exp$p.value, 3),
    ifelse(test_tox_exp$p.value < 0.05, " *** Différence", 
           " (pas de différence)"), "\n")
cat("  Impact émotionnel : p =", round(test_tox_imp$p.value, 3),
    ifelse(test_tox_imp$p.value < 0.05, " *** Femmes plus affectées", 
           " (pas de différence)"), "\n")
cat("  Corrélation H : r =", round(cor_h_exp$estimate, 3), "\n")
cat("  Corrélation F : r =", round(cor_f_exp$estimate, 3), "\n\n")

cat("SOMMEIL :\n")
cat("  Qualité : p =", round(test_sommeil_genre$p.value, 3),
    ifelse(test_sommeil_genre$p.value < 0.05, " ***", " (pas de différence)"), "\n\n")

cat("PERCEPTION DU NIVEAU :\n")
cat("  Écart H : M =", round(stats_ecart_genre[stats_ecart_genre$Genre_clean == "Homme", ]$M_ecart, 2), "\n")
cat("  Écart F : M =", round(stats_ecart_genre[stats_ecart_genre$Genre_clean == "Femme", ]$M_ecart, 2), "\n")
cat("  p =", round(test_ecart_genre$p.value, 3),
    ifelse(test_ecart_genre$p.value < 0.05, " ***", " (pas de différence)"), "\n\n")

cat("*** = p < 0.05 (significatif)\n")
cat("================================================================================\n")